// advanced-analyzer.js - Продвинутый анализатор транзакций
const crypto = require('crypto');

class AdvancedTransactionAnalyzer {
    constructor() {
        this.scamPatterns = this.loadScamPatterns();
        this.contractReputation = new Map();
        this.riskWeights = {
            unlimitedApprove: 0.9,
            zeroAddress: 0.8,
            highValue: 0.6,
            newContract: 0.5,
            suspiciousData: 0.7,
            phishingKeywords: 0.75,
            dustAttack: 0.65
        };
    }
    
    loadScamPatterns() {
        return {
            // Известные scam функции
            maliciousFunctions: [
                '0x60806040', // constructor with malicious code
                '0x5b7b72c9', // drain funds pattern
                '0x6661696c', // "fail" in hex
            ],
            
            // Phishing keywords in calldata/notes
            phishingKeywords: [
                'airdrop', 'reward', 'free', 'claim', 'bonus',
                'verification', 'security', 'update', 'migration',
                'walletconnect', 'metamask', 'trustwallet'
            ],
            
            // Known scam contract patterns
            scamPatterns: [
                {
                    name: 'Fake Transfer',
                    pattern: /transfer.*0x[a-f0-9]{40}.*reward/i,
                    risk: 0.85
                },
                {
                    name: 'Approval Drain',
                    pattern: /approve.*0x[a-f0-9]{40}.*0xf{64}/i,
                    risk: 0.95
                },
                {
                    name: 'Impersonation',
                    pattern: /uniswap|pancakeswap|sushiswap|compound|aave/i,
                    risk: 0.7
                }
            ],
            
            // Known malicious addresses (в реальном приложении нужно больше)
            blacklistedAddresses: [
                '0x000000000000000000000000000000000000dead',
                '0x0000000000000000000000000000000000000001',
                '0x1111111254fb6c44bac0bed2854e76f90643097d', // 1inch (пример, не scam)
            ]
        };
    }
    
    // Анализ семантики транзакции
    async analyzeSemantics(tx) {
        const analysis = {
            riskScore: 0,
            warnings: [],
            insights: [],
            confidence: 0,
            category: 'unknown'
        };
        
        // 1. Определяем категорию транзакции
        analysis.category = this.categorizeTransaction(tx);
        
        // 2. Проверяем на известные scam паттерны
        const scamResults = this.detectScamPatterns(tx);
        analysis.warnings.push(...scamResults.warnings);
        analysis.riskScore += scamResults.riskScore;
        
        // 3. Анализируем контекст (газ, время, частоту)
        const contextAnalysis = this.analyzeContext(tx);
        analysis.insights.push(...contextAnalysis.insights);
        analysis.riskScore += contextAnalysis.riskScore;
        
        // 4. Проверяем на сложные атаки
        const attackAnalysis = this.detectComplexAttacks(tx);
        analysis.warnings.push(...attackAnalysis.warnings);
        analysis.riskScore = Math.max(analysis.riskScore, attackAnalysis.riskScore);
        
        // 5. Нормализуем риск-скор (0-1)
        analysis.riskScore = Math.min(1, Math.max(0, analysis.riskScore));
        
        // 6. Рассчитываем уверенность
        analysis.confidence = this.calculateConfidence(tx, analysis);
        
        return analysis;
    }
    
    categorizeTransaction(tx) {
        if (tx.type === 'approve') {
            return tx.amount === 'unlimited' ? 'unlimited_approve' : 'limited_approve';
        }
        
        if (tx.data) {
            if (tx.data.includes('095ea7b3')) return 'token_approval';
            if (tx.data.includes('a9059cbb')) return 'token_transfer';
            if (tx.data.includes('23b872dd')) return 'token_transfer_from';
            return 'contract_interaction';
        }
        
        if (tx.to === '0x0000000000000000000000000000000000000000') {
            return 'burn';
        }
        
        return tx.value ? 'eth_transfer' : 'contract_deployment';
    }
    
    detectScamPatterns(tx) {
        const result = {
            riskScore: 0,
            warnings: []
        };
        
        const txString = JSON.stringify(tx).toLowerCase();
        
        // Проверка ключевых слов фишинга
        this.scamPatterns.phishingKeywords.forEach(keyword => {
            if (txString.includes(keyword)) {
                result.warnings.push(`Обнаружено фишинговое ключевое слово: "${keyword}"`);
                result.riskScore += this.riskWeights.phishingKeywords;
            }
        });
        
        // Проверка scam паттернов
        this.scamPatterns.scamPatterns.forEach(pattern => {
            if (pattern.pattern.test(txString)) {
                result.warnings.push(`Обнаружен паттерн "${pattern.name}"`);
                result.riskScore += pattern.risk;
            }
        });
        
        // Проверка чёрного списка адресов
        if (tx.to && this.scamPatterns.blacklistedAddresses.includes(tx.to.toLowerCase())) {
            result.warnings.push('Адрес получателя в чёрном списке!');
            result.riskScore += 0.9;
        }
        
        return result;
    }
    
    analyzeContext(tx) {
        const result = {
            riskScore: 0,
            insights: []
        };
        
        // Анализ газа
        if (tx.gasPrice) {
            const gasPrice = parseFloat(tx.gasPrice);
            if (gasPrice > 200) {
                result.insights.push(`Высокая цена газа: ${gasPrice} Gwei`);
                result.riskScore += 0.3;
            } else if (gasPrice < 5) {
                result.insights.push(`Очень низкая цена газа: ${gasPrice} Gwei`);
                result.riskScore += 0.2;
            }
        }
        
        // Анализ суммы
        if (tx.value) {
            const value = parseFloat(tx.value);
            if (value > 50) {
                result.insights.push(`Крупная сумма: ${value} ETH`);
                result.riskScore += this.riskWeights.highValue;
            } else if (value < 0.0001) {
                result.insights.push(`Dust атака? Сумма: ${value} ETH`);
                result.riskScore += this.riskWeights.dustAttack;
            }
            
            // Проверка круглых сумм
            if (value === 1 || value === 10 || value === 100 || value === 1000) {
                result.insights.push(`Круглая сумма: ${value} ETH (может быть фишинг)`);
                result.riskScore += 0.4;
            }
        }
        
        return result;
    }
    
    detectComplexAttacks(tx) {
        const result = {
            riskScore: 0,
            warnings: []
        };
        
        // Детектирование атаки на approve
        if (tx.data && tx.data.includes('095ea7b3')) {
            // Проверяем на максимальный approve
            if (tx.data.includes('ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff')) {
                result.warnings.push('⚠️ COMPLEX ATTACK: Unlimited approve detected');
                result.riskScore = Math.max(result.riskScore, this.riskWeights.unlimitedApprove);
            }
            
            // Проверяем approve к неизвестному контракту
            if (tx.to && this.isNewOrUnknownContract(tx.to)) {
                result.warnings.push('⚠️ Approve к новому/неизвестному контракту');
                result.riskScore += this.riskWeights.newContract;
            }
        }
        
        // Проверка на sandwich attack паттерны
        if (this.isSandwichAttackPattern(tx)) {
            result.warnings.push('⚠️ Возможная sandwich атака (MEV)');
            result.riskScore = Math.max(result.riskScore, 0.7);
        }
        
        // Проверка на frontrunning
        if (this.isFrontrunningPattern(tx)) {
            result.warnings.push('⚠️ Признаки frontrunning');
            result.riskScore = Math.max(result.riskScore, 0.6);
        }
        
        return result;
    }
    
    isNewOrUnknownContract(address) {
        // В реальном приложении здесь была бы проверка через Etherscan API
        // Пока возвращаем false для известных контрактов
        const knownContracts = [
            '0xdac17f958d2ee523a2206206994597c13d831ec7', // USDT
            '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48', // USDC
            '0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2', // WETH
        ];
        
        return !knownContracts.includes(address.toLowerCase());
    }
    
    isSandwichAttackPattern(tx) {
        // Простая эвристика для sandwich атак
        if (!tx.data) return false;
        
        const sandwichPatterns = [
            '0x7ff36ab5', // swapETHForExactTokens
            '0x18cbafe5', // swapExactTokensForETH
            '0x8803dbee', // swapTokensForExactTokens
        ];
        
        return sandwichPatterns.some(pattern => tx.data.includes(pattern));
    }
    
    isFrontrunningPattern(tx) {
        // Эвристика для frontrunning
        if (!tx.gasPrice) return false;
        
        const gasPrice = parseFloat(tx.gasPrice);
        return gasPrice > 150; // Очень высокий газ для frontrunning
    }
    
    calculateConfidence(tx, analysis) {
        let confidence = 0.5; // Базовая уверенность
        
        // Увеличиваем уверенность при наличии данных
        if (tx.data && tx.data.length > 10) confidence += 0.2;
        if (tx.value) confidence += 0.1;
        if (tx.to && tx.to.length === 42) confidence += 0.1;
        
        // Уменьшаем при подозрительных паттернах
        if (analysis.warnings.length > 3) confidence -= 0.2;
        
        return Math.max(0.1, Math.min(1, confidence));
    }
    
    // Конвертируем анализ в финальный риск
    convertToRiskLevel(analysis) {
        if (analysis.riskScore >= 0.8) return 'high';
        if (analysis.riskScore >= 0.5) return 'medium';
        return 'low';
    }
    
    // Генерируем человеко-читаемые рекомендации
    generateRecommendations(analysis, tx) {
        const recommendations = [];
        
        if (analysis.riskScore >= 0.8) {
            recommendations.push('🚨 ВЫСОКИЙ РИСК: Рассмотрите отмену транзакции');
            recommendations.push('⚠️ Проверьте контракт на Etherscan');
            recommendations.push('🔍 Поищите отзывы об этом контракте');
        }
        
        if (analysis.category === 'unlimited_approve') {
            recommendations.push('🔒 Используйте лимитированный approve');
            recommendations.push('⏰ Установите лимит по времени');
            recommendations.push('📊 Проверьте репутацию контракта');
        }
        
        if (analysis.warnings.some(w => w.includes('фишинговое'))) {
            recommendations.push('🎣 Возможен фишинг - проверьте источник');
            recommendations.push('🔗 Не переходите по подозрительным ссылкам');
        }
        
        // Общие рекомендации
        recommendations.push('✅ Всегда проверяйте адрес получателя');
        recommendations.push('📝 Сохраняйте чек перед отправкой');
        recommendations.push('⏳ Для крупных сумм используйте multi-sig');
        
        return recommendations;
    }
}

module.exports = AdvancedTransactionAnalyzer;