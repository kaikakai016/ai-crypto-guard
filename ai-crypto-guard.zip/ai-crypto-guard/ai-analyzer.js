// ai-analyzer.js - AI анализатор транзакций с поддержкой OpenRouter API
// OpenRouter даёт доступ к множеству AI моделей: GPT-4, Claude, Llama и др.

const fs = require('fs').promises;
const path = require('path');

class AIAnalyzer {
    constructor(apiKey = null) {
        // Берем ключ из параметра или из .env файла
        const key = apiKey || process.env.OPENROUTER_API_KEY || process.env.OPENAI_API_KEY;
        
        console.log('🔑 Проверяем API ключ...');
        
        this.apiKey = key;
        this.enabled = false;
        this.useSimulation = false;
        this.model = process.env.AI_MODEL || "anthropic/claude-3.5-sonnet";
        this.cache = new Map();
        this.cacheFile = path.join(__dirname, 'ai-cache.json');
        this.baseUrl = "https://openrouter.ai/api/v1";
        
        // Пробуем загрузить кэш
        this.loadCache();
        
        if (!key) {
            console.warn('⚠️ OpenRouter API ключ не найден');
            console.warn('   Добавьте OPENROUTER_API_KEY в .env файл');
            console.warn('   Получить ключ: https://openrouter.ai/keys');
            console.warn('   Будет использоваться симуляция AI');
            this.useSimulation = true;
        } else {
            this.enabled = true;
            console.log('✅ OpenRouter API настроен');
            console.log('   Модель:', this.model);
            console.log('   Доступные модели: https://openrouter.ai/models');
        }
        
        if (this.useSimulation) {
            console.log('🤖 AI отключен, будет использоваться симуляция');
        }
    }
    
    // Загрузка кэша из файла
    async loadCache() {
        try {
            const data = await fs.readFile(this.cacheFile, 'utf8');
            const parsed = JSON.parse(data);
            this.cache = new Map(Object.entries(parsed));
            console.log(`📦 Загружено ${this.cache.size} кэшированных результатов`);
        } catch (error) {
            this.cache = new Map();
        }
    }
    
    // Сохранение кэша в файл
    async saveCache() {
        try {
            const data = Object.fromEntries(this.cache);
            await fs.writeFile(this.cacheFile, JSON.stringify(data, null, 2), 'utf8');
        } catch (error) {
            console.error('❌ Ошибка сохранения кэша:', error.message);
        }
    }
    
    // Генерация ключа кэша для транзакции
    getCacheKey(tx) {
        const crypto = require('crypto');
        const txString = JSON.stringify(tx);
        return crypto.createHash('md5').update(txString).digest('hex');
    }
    
    // Основной метод анализа транзакции
    async analyzeTransaction(tx) {
        // Проверяем кэш
        const cacheKey = this.getCacheKey(tx);
        if (this.cache.has(cacheKey)) {
            console.log('📦 Используем кэшированный результат');
            return {
                ...this.cache.get(cacheKey),
                fromCache: true
            };
        }
        
        // Если AI не доступен, используем симуляцию
        if (!this.enabled || this.useSimulation) {
            console.log('🤖 Используем симуляцию AI анализа');
            const result = this.simulateAnalysis(tx);
            this.cache.set(cacheKey, result);
            await this.saveCache();
            return result;
        }
        
        try {
            console.log('🤖 Отправляем запрос к OpenRouter...');
            
            const prompt = this.buildPrompt(tx);
            
            const response = await fetch(`${this.baseUrl}/chat/completions`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${this.apiKey}`,
                    'HTTP-Referer': process.env.APP_URL || 'http://localhost:3000',
                    'X-Title': 'AI Crypto Guard'
                },
                body: JSON.stringify({
                    model: this.model,
                    messages: [
                        {
                            role: "system",
                            content: `You are a cryptocurrency security expert. Analyze Ethereum transactions for potential risks and scams. 
                            Respond ONLY with a JSON object in this exact format:
                            {
                                "risk": "high|medium|low",
                                "confidence": 0.0-1.0,
                                "category": "category_name",
                                "explanation": "brief explanation in Russian",
                                "red_flags": ["flag1", "flag2"],
                                "recommendations": ["rec1", "rec2"]
                            }`
                        },
                        {
                            role: "user",
                            content: prompt
                        }
                    ],
                    temperature: 0.3,
                    max_tokens: 500,
                    response_format: { type: "json_object" }
                })
            });
            
            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.error?.message || `HTTP ${response.status}`);
            }
            
            const data = await response.json();
            const content = data.choices[0]?.message?.content;
            
            if (!content) {
                throw new Error('Empty response from API');
            }
            
            // Парсим JSON ответ
            let result;
            try {
                result = JSON.parse(content);
            } catch (parseError) {
                console.error('❌ Ошибка парсинга ответа AI:', parseError.message);
                console.log('Ответ AI:', content);
                // Fallback к симуляции
                result = this.simulateAnalysis(tx);
            }
            
            // Добавляем метаданные
            result.fromOpenRouter = true;
            result.model = this.model;
            result.timestamp = new Date().toISOString();
            
            // Сохраняем в кэш
            this.cache.set(cacheKey, result);
            await this.saveCache();
            
            console.log('✅ AI анализ завершен через OpenRouter');
            return result;
            
        } catch (error) {
            console.error('❌ Ошибка AI анализа:', error.message);
            // Fallback к симуляции при ошибке
            const result = this.simulateAnalysis(tx);
            result.aiError = error.message;
            result.fromOpenRouter = false;
            return result;
        }
    }
    
    // Построение промпта для AI
    buildPrompt(tx) {
        let prompt = `Analyze this Ethereum transaction for security risks:\n\n`;
        
        prompt += `Transaction Details:\n`;
        if (tx.to) prompt += `- To: ${tx.to}\n`;
        if (tx.from) prompt += `- From: ${tx.from}\n`;
        if (tx.value) prompt += `- Value: ${tx.value} ETH\n`;
        if (tx.gas) prompt += `- Gas Limit: ${tx.gas}\n`;
        if (tx.gasPrice) prompt += `- Gas Price: ${tx.gasPrice} Gwei\n`;
        if (tx.data) prompt += `- Data: ${tx.data}\n`;
        if (tx.type) prompt += `- Type: ${tx.type}\n`;
        
        // Декодируем data если это approve
        if (tx.data && tx.data.includes('095ea7b3')) {
            prompt += `\n⚠️ This is an APPROVE transaction - giving token spending permission!\n`;
            if (tx.data.includes('ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff')) {
                prompt += `🚨 UNLIMITED APPROVE detected - very dangerous!\n`;
            }
        }
        
        // Проверка на нулевой адрес
        if (tx.to === '0x0000000000000000000000000000000000000000') {
            prompt += `\n⚠️ Sending to ZERO ADDRESS (burn address)!\n`;
        }
        
        prompt += `\nProvide security analysis in the specified JSON format.`;
        
        return prompt;
    }
    
    // Симуляция AI анализа (когда нет API ключа)
    simulateAnalysis(tx) {
        console.log('🎭 Симулируем AI анализ...');
        
        let risk = 'low';
        let confidence = 0.7;
        let category = 'normal_transfer';
        let explanation = 'Транзакция выглядит безопасной.';
        let redFlags = [];
        let recommendations = ['✅ Всегда проверяйте адрес получателя'];
        
        // Анализируем различные факторы риска
        
        // 1. Проверка unlimited approve
        if (tx.data && tx.data.includes('095ea7b3')) {
            category = 'token_approval';
            if (tx.data.includes('ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff')) {
                risk = 'high';
                confidence = 0.95;
                explanation = 'Обнаружен неограниченный доступ к токенам (unlimited approve). Контракт сможет потратить ВСЕ ваши токены без ограничений!';
                redFlags.push('Unlimited token approval');
                redFlags.push('Contract can drain all tokens');
                recommendations.push('🔒 Используйте лимитированный approve с конкретной суммой');
                recommendations.push('⏰ Установите лимит по времени через decreaseAllowance');
                recommendations.push('🔍 Проверьте контракт на Etherscan перед approval');
            } else {
                risk = 'medium';
                confidence = 0.6;
                explanation = 'Выдается разрешение на использование токенов. Убедитесь, что доверяете этому контракту.';
                redFlags.push('Token approval requested');
                recommendations.push('✅ Проверьте адрес контракта');
                recommendations.push('💡 Можно установить лимит по времени');
            }
        }
        
        // 2. Проверка на нулевой адрес
        if (tx.to === '0x0000000000000000000000000000000000000000') {
            risk = 'high';
            confidence = 0.9;
            category = 'token_burn';
            explanation = 'Отправка на нулевой адрес (сжигание токенов). Это навсегда уничтожит ваши токены!';
            redFlags.push('Sending to burn address');
            redFlags.push('Tokens will be permanently destroyed');
            recommendations.push('🔥 Токены будут безвозвратно уничтожены');
            recommendations.push('⏸️ Убедитесь, что это действительно нужно');
        }
        
        // 3. Проверка больших сумм
        if (tx.value && parseFloat(tx.value) > 5) {
            if (risk !== 'high') risk = 'medium';
            confidence = 0.75;
            category = 'large_transfer';
            explanation = 'Крупная сумма транзакции. Дважды проверьте адрес получателя.';
            redFlags.push(`Large amount: ${tx.value} ETH`);
            recommendations.push('💰 Дважды проверьте адрес получателя');
            recommendations.push('🧪 Можно отправить сначала маленькую сумму');
        }
        
        // 4. Проверка подозрительных паттернов в данных
        if (tx.data) {
            const suspiciousPatterns = [
                { pattern: /transferFrom/i, flag: 'transferFrom - someone can transfer your tokens' },
                { pattern: /safeTransferFrom/i, flag: 'NFT transfer function' },
                { pattern: /setApprovalForAll/i, flag: 'Full NFT collection approval' }
            ];
            
            suspiciousPatterns.forEach(({ pattern, flag }) => {
                if (pattern.test(tx.data)) {
                    redFlags.push(flag);
                    if (risk === 'low') {
                        risk = 'medium';
                        confidence = 0.65;
                    }
                }
            });
        }
        
        // 5. Проверка газа
        if (tx.gasPrice && parseFloat(tx.gasPrice) > 200) {
            redFlags.push(`Very high gas price: ${tx.gasPrice} Gwei`);
            recommendations.push('⛽ Высокая цена газа - возможен фронтраннинг');
        }
        
        // 6. Проверка невалидного адреса
        if (tx.to && !this.isValidAddress(tx.to)) {
            risk = 'high';
            confidence = 0.95;
            explanation = 'Неверный формат Ethereum адреса получателя!';
            redFlags.push('Invalid recipient address format');
            recommendations.push('❌ Проверьте адрес получателя');
        }
        
        return {
            risk,
            confidence,
            category,
            explanation,
            red_flags: redFlags,
            recommendations,
            fromOpenRouter: false,
            simulated: true,
            timestamp: new Date().toISOString()
        };
    }
    
    // Проверка валидности Ethereum адреса
    isValidAddress(address) {
        if (!address || typeof address !== 'string') return false;
        const cleanAddress = address.trim();
        if (cleanAddress.length !== 42) return false;
        if (!cleanAddress.startsWith('0x')) return false;
        const hexPart = cleanAddress.substring(2);
        const hexRegex = /^[0-9a-fA-F]+$/;
        return hexRegex.test(hexPart);
    }
    
    // Получение доступных моделей от OpenRouter
    async getAvailableModels() {
        try {
            const response = await fetch('https://openrouter.ai/api/v1/models', {
                headers: {
                    'Authorization': `Bearer ${this.apiKey}`
                }
            });
            
            if (!response.ok) {
                throw new Error('Failed to fetch models');
            }
            
            const data = await response.json();
            return data.data.map(m => ({
                id: m.id,
                name: m.name,
                description: m.description,
                pricing: m.pricing
            }));
        } catch (error) {
            console.error('❌ Ошибка получения моделей:', error.message);
            return [];
        }
    }
    
    // Получение статистики кэша
    getCacheStats() {
        return {
            size: this.cache.size,
            enabled: this.enabled,
            usingSimulation: this.useSimulation,
            model: this.model
        };
    }
    
    // Очистка кэша
    async clearCache() {
        this.cache.clear();
        await this.saveCache();
        console.log('🗑️ Кэш AI анализа очищен');
    }
}

module.exports = AIAnalyzer;
