// content.js - Улучшенный перехват транзакций MetaMask

console.log('🛡️ AI Crypto Guard content script loaded');

// Флаг для отслеживания инициализации
let isInitialized = false;

// Ждем загрузки страницы
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initialize);
} else {
  initialize();
}

function initialize() {
  if (isInitialized) return;
  isInitialized = true;
  
  console.log('🔍 AI Crypto Guard initializing...');
  
  // Небольшая задержка для гарантии загрузки MetaMask
  setTimeout(() => {
    injectTransactionInterceptor();
  }, 500);
}

// Внедрение перехватчика транзакций
function injectTransactionInterceptor() {
  const script = document.createElement('script');
  script.textContent = `
    (function() {
      console.log('🔍 AI Crypto Guard monitoring started');
      
      // Хранилище для оригинальных функций
      const originalFunctions = {};
      
      // Перехват MetaMask (window.ethereum)
      function interceptMetaMask() {
        if (!window.ethereum) {
          console.log('⏳ MetaMask not found, retrying...');
          setTimeout(interceptMetaMask, 1000);
          return;
        }
        
        console.log('✅ MetaMask detected, installing interceptor');
        
        // Сохраняем оригинальный request
        originalFunctions.ethereumRequest = window.ethereum.request.bind(window.ethereum);
        
        // Переопределяем request
        window.ethereum.request = async function(request) {
          // Анализируем только транзакции
          if (request.method === 'eth_sendTransaction' || 
              request.method === 'eth_signTransaction') {
            
            const tx = request.params[0];
            console.log('📝 Transaction detected:', {
              to: tx?.to,
              value: tx?.value,
              data: tx?.data?.substring(0, 66) + '...'
            });
            
            try {
              // Отправляем на анализ через расширение
              const response = await window.postMessage({
                type: 'AI_CRYPTO_GUARD_ANALYZE',
                tx: tx,
                timestamp: Date.now()
              }, '*');
              
            } catch (error) {
              console.log('⚠️ Analysis message error:', error.message);
            }
          }
          
          // Вызываем оригинальный метод
          return originalFunctions.ethereumRequest(request);
        };
        
        console.log('✅ MetaMask interceptor installed');
      }
      
      // Перехват Web3.js (если используется)
      function interceptWeb3() {
        if (window.web3 && window.web3.eth) {
          console.log('✅ Web3 detected');
          
          // Сохраняем оригинальный sendTransaction
          if (window.web3.eth.sendTransaction) {
            originalFunctions.web3SendTransaction = window.web3.eth.sendTransaction.bind(window.web3.eth);
            
            window.web3.eth.sendTransaction = async function(tx, callback) {
              console.log('📝 Web3 transaction detected:', tx);
              
              try {
                window.postMessage({
                  type: 'AI_CRYPTO_GUARD_ANALYZE',
                  tx: tx,
                  timestamp: Date.now()
                }, '*');
              } catch (error) {
                console.log('⚠️ Web3 analysis error:', error);
              }
              
              return originalFunctions.web3SendTransaction(tx, callback);
            };
          }
        }
      }
      
      // Перехват WalletConnect (если используется)
      function interceptWalletConnect() {
        // Проверяем наличие WalletConnect провайдера
        if (window.walletconnect || window.WalletConnectProvider) {
          console.log('✅ WalletConnect detected');
        }
      }
      
      // Инициализация перехватов
      interceptMetaMask();
      interceptWeb3();
      interceptWalletConnect();
      
      // Слушаем добавление новых провайдеров
      window.addEventListener('ethereum#initialized', () => {
        console.log('🔄 MetaMask re-initialized, reinstalling interceptor');
        interceptMetaMask();
      });
      
    })();
  `;
  
  document.documentElement.appendChild(script);
  script.remove();
  
  console.log('✅ Transaction interceptor injected');
}

// Слушаем сообщения от внедренного скрипта
window.addEventListener('message', async (event) => {
  // Проверяем, что сообщение от нашего скрипта
  if (event.data?.type === 'AI_CRYPTO_GUARD_ANALYZE') {
    const tx = event.data.tx;
    
    try {
      // Отправляем на анализ через background.js
      const response = await chrome.runtime.sendMessage({
        action: 'ANALYZE_TRANSACTION',
        data: tx
      });
      
      if (response.success && response.data.risk === 'high') {
        // Показываем предупреждение пользователю
        showTransactionWarning(response.data, tx);
      }
      
    } catch (error) {
      console.error('❌ Analysis error:', error);
    }
  }
});

// Показать предупреждение о транзакции
function showTransactionWarning(analysis, tx) {
  // Создаем модальное окно
  const modal = document.createElement('div');
  modal.id = 'ai-crypto-guard-warning';
  modal.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    z-index: 999999;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  `;
  
  const content = document.createElement('div');
  content.style.cssText = `
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
    border-radius: 16px;
    padding: 30px;
    max-width: 450px;
    width: 90%;
    border: 2px solid #ef4444;
    box-shadow: 0 20px 60px rgba(239, 68, 68, 0.3);
  `;
  
  content.innerHTML = `
    <div style="text-align: center; margin-bottom: 20px;">
      <div style="font-size: 48px; margin-bottom: 10px;">🚨</div>
      <h2 style="color: #ef4444; margin: 0; font-size: 24px;">ВЫСОКИЙ РИСК!</h2>
    </div>
    
    <div style="background: rgba(239, 68, 68, 0.1); border-radius: 8px; padding: 15px; margin-bottom: 20px;">
      <p style="color: #fff; margin: 0 0 10px 0; font-size: 14px; line-height: 1.5;">
        ${analysis.explanation}
      </p>
    </div>
    
    <div style="margin-bottom: 20px;">
      <h3 style="color: #9ca3af; font-size: 12px; text-transform: uppercase; margin-bottom: 10px;">Рекомендации:</h3>
      <ul style="color: #d1d5db; font-size: 13px; line-height: 1.6; margin: 0; padding-left: 20px;">
        ${analysis.recommendations?.slice(0, 3).map(r => `<li>${r}</li>`).join('') || '<li>Проверьте транзакцию вручную</li>'}
      </ul>
    </div>
    
    <div style="display: flex; gap: 10px;">
      <button id="ai-guard-cancel" style="
        flex: 1;
        background: #ef4444;
        color: white;
        border: none;
        padding: 12px;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        font-size: 14px;
      ">❌ Отменить транзакцию</button>
      
      <button id="ai-guard-continue" style="
        flex: 1;
        background: transparent;
        color: #9ca3af;
        border: 1px solid #4b5563;
        padding: 12px;
        border-radius: 8px;
        font-weight: 600;
        cursor: pointer;
        font-size: 14px;
      ">⚠️ Продолжить</button>
    </div>
    
    <div style="text-align: center; margin-top: 15px;">
      <a href="http://localhost:3000" target="_blank" style="
        color: #667eea;
        text-decoration: none;
        font-size: 12px;
      ">Подробнее в дашборде →</a>
    </div>
  `;
  
  modal.appendChild(content);
  document.body.appendChild(modal);
  
  // Обработчики кнопок
  document.getElementById('ai-guard-cancel').addEventListener('click', () => {
    modal.remove();
    // Отправляем сообщение об отмене
    window.postMessage({
      type: 'AI_CRYPTO_GUARD_CANCEL',
      tx: tx
    }, '*');
  });
  
  document.getElementById('ai-guard-continue').addEventListener('click', () => {
    modal.remove();
  });
}

// Слушаем сообщения от фонового скрипта
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'PING') {
    sendResponse({ status: 'active', timestamp: Date.now() });
  }
  
  if (request.action === 'SHOW_WARNING') {
    showTransactionWarning(request.analysis, request.tx);
    sendResponse({ shown: true });
  }
});

console.log('🛡️ AI Crypto Guard content script initialized');
