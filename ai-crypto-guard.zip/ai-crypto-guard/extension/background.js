// background.js - Улучшенная фоновая служба AI Crypto Guard

console.log('🛡️ AI Crypto Guard extension loaded');

// Настройки
const BACKEND_URL = 'http://localhost:3000';
let isEnabled = true;
let backendConnected = false;

// Инициализация при установке
chrome.runtime.onInstalled.addListener(() => {
  console.log('✅ AI Crypto Guard установлен');
  
  // Устанавливаем начальные значения
  chrome.storage.local.set({
    enabled: true,
    totalAnalyzed: 0,
    highRisk: 0,
    firstInstall: true
  });
  
  // Проверяем подключение к бэкенду
  checkConnection();
});

// Обработчик сообщений
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 Message received:', request.action);
  
  switch (request.action) {
    case 'ANALYZE_TRANSACTION':
      handleAnalyzeTransaction(request.data)
        .then(result => sendResponse({ success: true, data: result }))
        .catch(error => sendResponse({ success: false, error: error.message }));
      return true; // Важно для асинхронного ответа
      
    case 'TOGGLE_ENABLED':
      isEnabled = request.enabled;
      chrome.storage.local.set({ enabled: isEnabled });
      sendResponse({ success: true, enabled: isEnabled });
      break;
      
    case 'GET_STATUS':
      sendResponse({ 
        enabled: isEnabled, 
        backend: BACKEND_URL,
        backendConnected: backendConnected 
      });
      break;
      
    case 'CHECK_CONNECTION':
      checkConnection()
        .then(connected => sendResponse({ connected }))
        .catch(error => sendResponse({ connected: false, error: error.message }));
      return true;
  }
});

// Обработка анализа транзакции
async function handleAnalyzeTransaction(txData) {
  if (!isEnabled) {
    throw new Error('Расширение отключено');
  }
  
  try {
    console.log('🔍 Analyzing transaction:', txData);
    
    // Добавляем метаданные
    const enrichedTx = {
      ...txData,
      source: 'chrome_extension',
      timestamp: new Date().toISOString()
    };
    
    const response = await fetch(`${BACKEND_URL}/analyze`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(enrichedTx)
    });
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error || `Server error: ${response.status}`);
    }
    
    const result = await response.json();
    
    // Обновляем локальную статистику
    await updateLocalStats(result.risk);
    
    // Показываем уведомление для высокого риска
    if (result.risk === 'high') {
      showHighRiskNotification(result);
    }
    
    // Отправляем сообщение в popup для обновления UI
    chrome.runtime.sendMessage({
      action: 'ANALYSIS_COMPLETE',
      data: result
    }).catch(() => {});
    
    return result;
    
  } catch (error) {
    console.error('❌ Analysis failed:', error);
    
    // Если бэкенд недоступен, используем локальный анализ
    if (!backendConnected) {
      console.log('🔄 Using local fallback analysis');
      return localAnalyzeTransaction(txData);
    }
    
    throw error;
  }
}

// Локальный анализ (fallback когда бэкенд недоступен)
function localAnalyzeTransaction(tx) {
  let risk = 'low';
  let message = 'Транзакция выглядит безопасно.';
  let recommendations = [];
  
  // Проверка unlimited approve
  if (tx.data && tx.data.includes('095ea7b3') && 
      tx.data.includes('ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff')) {
    risk = 'high';
    message = '🚨 ОПАСНО: Обнаружен неограниченный доступ к токенам!';
    recommendations.push('Используйте лимитированный approve');
  }
  
  // Проверка на нулевой адрес
  else if (tx.to === '0x0000000000000000000000000000000000000000') {
    risk = 'high';
    message = '⚠️ Отправка на нулевой адрес (сожжение токенов)!';
    recommendations.push('Токены будут безвозвратно уничтожены');
  }
  
  // Проверка больших сумм
  else if (tx.value && parseFloat(tx.value) > 5) {
    risk = 'medium';
    message = 'Крупная сумма транзакции';
    recommendations.push('Дважды проверьте адрес получателя');
  }
  
  return {
    risk,
    explanation: message,
    recommendations,
    fromLocal: true,
    timestamp: new Date().toISOString()
  };
}

// Обновление локальной статистики
async function updateLocalStats(risk) {
  try {
    const result = await chrome.storage.local.get(['totalAnalyzed', 'highRisk']);
    const total = (result.totalAnalyzed || 0) + 1;
    const highRisk = (result.highRisk || 0) + (risk === 'high' ? 1 : 0);
    
    await chrome.storage.local.set({
      totalAnalyzed: total,
      highRisk: highRisk
    });
  } catch (error) {
    console.error('Failed to update stats:', error);
  }
}

// Показать уведомление о высоком риске
function showHighRiskNotification(analysis) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: '🚨 ВЫСОКИЙ РИСК ТРАНЗАКЦИИ!',
    message: analysis.explanation?.substring(0, 100) + '...' || 'Обнаружена подозрительная транзакция!',
    priority: 2,
    buttons: [
      { title: 'Подробнее' },
      { title: 'Игнорировать' }
    ]
  });
}

// Проверка подключения к серверу
async function checkConnection() {
  try {
    const response = await fetch(`${BACKEND_URL}/system-info`, {
      method: 'GET',
      headers: { 'Accept': 'application/json' }
    });
    
    if (response.ok) {
      const data = await response.json();
      console.log('✅ Backend connected:', data.name);
      backendConnected = true;
      return true;
    } else {
      throw new Error('Backend returned error');
    }
  } catch (error) {
    console.warn('⚠️ Backend not available:', error.message);
    backendConnected = false;
    return false;
  }
}

// Периодическая проверка подключения
setInterval(checkConnection, 30000); // Каждые 30 секунд

// Проверяем подключение при запуске
checkConnection();

// Обработка кликов на уведомлениях
chrome.notifications.onButtonClicked.addListener((notificationId, buttonIndex) => {
  if (buttonIndex === 0) {
    // Открываем дашборд
    chrome.tabs.create({ url: 'http://localhost:3000' });
  }
  chrome.notifications.clear(notificationId);
});

// Обработка клика на уведомлении
chrome.notifications.onClicked.addListener((notificationId) => {
  chrome.tabs.create({ url: 'http://localhost:3000' });
  chrome.notifications.clear(notificationId);
});

console.log('🛡️ AI Crypto Guard background service initialized');
