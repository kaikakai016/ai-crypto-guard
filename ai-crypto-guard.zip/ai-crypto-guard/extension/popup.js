// popup.js - Улучшенный обработчик попапа AI Crypto Guard

// Состояние расширения
let extensionState = {
  enabled: true,
  backendConnected: false,
  totalAnalyzed: 0,
  highRisk: 0,
  lastAnalysis: null
};

// DOM Elements
let statusEl, toggleEnabled, totalAnalyzedEl, highRiskEl, lastAnalysisEl, lastRiskEl, riskIndicator;

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', async () => {
  console.log('🎪 AI Crypto Guard Popup loaded');
  
  // Инициализация DOM элементов
  initializeElements();
  
  // Загружаем статус
  await loadStatus();
  
  // Загружаем статистику с бэкенда
  await loadStats();
  
  // Настраиваем обработчики
  setupEventListeners();
});

// Инициализация DOM элементов
function initializeElements() {
  statusEl = document.getElementById('status');
  toggleEnabled = document.getElementById('toggle-enabled');
  totalAnalyzedEl = document.getElementById('total-analyzed');
  highRiskEl = document.getElementById('high-risk');
  lastAnalysisEl = document.getElementById('last-analysis');
  lastRiskEl = document.getElementById('last-risk');
  riskIndicator = document.getElementById('risk-indicator');
}

// Настройка обработчиков событий
function setupEventListeners() {
  // Переключатель включения/выключения
  toggleEnabled.addEventListener('change', toggleEnabledHandler);
  
  // Кнопки
  document.getElementById('test-btn').addEventListener('click', testTransaction);
  document.getElementById('history-btn').addEventListener('click', openHistory);
  document.getElementById('settings-btn').addEventListener('click', openSettings);
  document.getElementById('refresh-btn')?.addEventListener('click', loadStats);
}

// Загрузка статуса расширения
async function loadStatus() {
  try {
    const status = await chrome.runtime.sendMessage({ action: 'GET_STATUS' });
    extensionState.enabled = status.enabled;
    extensionState.backendConnected = status.backendConnected || false;
    updateStatusUI();
  } catch (error) {
    console.error('Failed to load status:', error);
    showMessage('❌ Ошибка подключения');
  }
}

// Обновление UI статуса
function updateStatusUI() {
  if (extensionState.enabled) {
    statusEl.textContent = 'АКТИВЕН';
    statusEl.className = 'status active';
    toggleEnabled.checked = true;
  } else {
    statusEl.textContent = 'ВЫКЛЮЧЕН';
    statusEl.className = 'status inactive';
    toggleEnabled.checked = false;
  }
}

// Переключение включения/выключения
async function toggleEnabledHandler(event) {
  const enabled = event.target.checked;
  
  try {
    const response = await chrome.runtime.sendMessage({
      action: 'TOGGLE_ENABLED',
      enabled: enabled
    });
    
    extensionState.enabled = response.enabled;
    updateStatusUI();
    showMessage(enabled ? '✅ Анализ включен' : '⏸️ Анализ выключен');
    
  } catch (error) {
    console.error('Toggle failed:', error);
    event.target.checked = !enabled;
    showMessage('❌ Ошибка переключения');
  }
}

// Загрузка статистики с бэкенда
async function loadStats() {
  try {
    // Получаем статистику с бэкенда
    const response = await fetch('http://localhost:3000/stats');
    if (!response.ok) throw new Error('Failed to fetch stats');
    
    const stats = await response.json();
    
    // Подсчитываем общее количество и высокий риск
    let total = 0;
    let highRisk = 0;
    
    stats.forEach(stat => {
      total += stat.count;
      if (stat.risk_level === 'high') {
        highRisk = stat.count;
      }
    });
    
    extensionState.totalAnalyzed = total;
    extensionState.highRisk = highRisk;
    
    // Обновляем UI
    totalAnalyzedEl.textContent = total;
    highRiskEl.textContent = highRisk;
    
    // Загружаем последние транзакции
    await loadRecentTransactions();
    
  } catch (error) {
    console.error('Stats load failed:', error);
    // Используем данные из локального хранилища как fallback
    loadLocalStats();
  }
}

// Загрузка локальной статистики
function loadLocalStats() {
  chrome.storage.local.get(['totalAnalyzed', 'highRisk'], (result) => {
    extensionState.totalAnalyzed = result.totalAnalyzed || 0;
    extensionState.highRisk = result.highRisk || 0;
    
    totalAnalyzedEl.textContent = extensionState.totalAnalyzed;
    highRiskEl.textContent = extensionState.highRisk;
  });
}

// Загрузка последних транзакций
async function loadRecentTransactions() {
  try {
    const response = await fetch('http://localhost:3000/recent?limit=1');
    if (!response.ok) throw new Error('Failed to fetch recent');
    
    const recent = await response.json();
    
    if (recent.length > 0) {
      const lastTx = recent[0];
      extensionState.lastAnalysis = lastTx;
      
      // Показываем последний анализ
      lastAnalysisEl.style.display = 'block';
      lastRiskEl.textContent = `${lastTx.risk_level.toUpperCase()} - ${lastTx.explanation.substring(0, 50)}...`;
      
      // Устанавливаем цвет индикатора
      riskIndicator.className = 'risk-indicator risk-' + lastTx.risk_level;
    }
  } catch (error) {
    console.error('Failed to load recent transactions:', error);
  }
}

// Тестовая транзакция
async function testTransaction() {
  const testTx = {
    to: '0x742d35Cc6634C0532925a3b844Bc9e7575f0D5E2',
    value: '1.5',
    data: '0x095ea7b3ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff',
    type: 'approve'
  };
  
  try {
    showMessage('🔍 Анализируем...');
    
    const response = await chrome.runtime.sendMessage({
      action: 'ANALYZE_TRANSACTION',
      data: testTx
    });
    
    if (response.success) {
      const analysis = response.data;
      showMessage(`✅ Результат: ${analysis.risk.toUpperCase()}`);
      
      // Показываем результат
      lastAnalysisEl.style.display = 'block';
      lastRiskEl.textContent = analysis.explanation;
      
      riskIndicator.className = 'risk-indicator risk-' + analysis.risk;
      
      // Обновляем статистику
      extensionState.totalAnalyzed++;
      if (analysis.risk === 'high') {
        extensionState.highRisk++;
      }
      
      totalAnalyzedEl.textContent = extensionState.totalAnalyzed;
      highRiskEl.textContent = extensionState.highRisk;
      
      // Сохраняем локально
      chrome.storage.local.set({
        totalAnalyzed: extensionState.totalAnalyzed,
        highRisk: extensionState.highRisk
      });
      
    } else {
      showMessage('❌ Ошибка: ' + response.error);
    }
    
  } catch (error) {
    showMessage('❌ Ошибка анализа');
    console.error('Test failed:', error);
  }
}

// Открытие истории
function openHistory() {
  chrome.tabs.create({ url: 'http://localhost:3000/history.html' });
}

// Открытие настроек
function openSettings() {
  chrome.tabs.create({ url: 'http://localhost:3000' });
}

// Показать сообщение
function showMessage(text) {
  const originalText = statusEl.textContent;
  const originalClass = statusEl.className;
  
  statusEl.textContent = text;
  statusEl.className = 'status info';
  
  setTimeout(() => {
    statusEl.textContent = originalText;
    statusEl.className = originalClass;
  }, 3000);
}

// Слушаем сообщения от background.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'ANALYSIS_COMPLETE') {
    // Обновляем статистику когда приходит новый анализ
    loadStats();
  }
});
