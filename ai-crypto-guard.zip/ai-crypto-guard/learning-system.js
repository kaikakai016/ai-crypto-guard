// learning-system.js - Система обучения на основе пользовательских решений
const fs = require('fs').promises;
const path = require('path');

class LearningSystem {
    constructor() {
        this.learningFile = path.join(__dirname, 'learning-data.json');
        this.patterns = new Map();
        this.userDecisions = [];
        this.loadLearningData();
    }
    
    async loadLearningData() {
        try {
            const data = await fs.readFile(this.learningFile, 'utf8');
            const parsed = JSON.parse(data);
            this.patterns = new Map(parsed.patterns || []);
            this.userDecisions = parsed.decisions || [];
            console.log('✅ Загружены данные обучения:', this.patterns.size, 'паттернов');
        } catch (error) {
            console.log('📭 Файл обучения не найден, создаём новый');
            await this.saveLearningData();
        }
    }
    
    async saveLearningData() {
        const data = {
            patterns: Array.from(this.patterns.entries()),
            decisions: this.userDecisions.slice(-1000) // Храним последние 1000 решений
        };
        
        await fs.writeFile(this.learningFile, JSON.stringify(data, null, 2), 'utf8');
    }
    
    // Регистрируем решение пользователя
    async recordDecision(txHash, predictedRisk, userAction, actualOutcome) {
        const decision = {
            timestamp: new Date().toISOString(),
            txHash,
            predictedRisk,
            userAction, // 'approved', 'rejected', 'modified'
            actualOutcome, // 'safe', 'scam', 'unknown'
            features: this.extractFeatures(txHash)
        };
        
        this.userDecisions.push(decision);
        
        // Обновляем веса паттернов
        if (actualOutcome === 'scam' && predictedRisk !== 'high') {
            this.adjustPatternWeights(decision.features, 0.1); // Увеличиваем вес
        } else if (actualOutcome === 'safe' && predictedRisk === 'high') {
            this.adjustPatternWeights(decision.features, -0.05); // Уменьшаем вес
        }
        
        await this.saveLearningData();
    }
    
    extractFeatures(txData) {
        const features = [];
        
        // Извлекаем ключевые признаки для обучения
        if (txData.type === 'approve') features.push('type_approve');
        if (txData.amount === 'unlimited') features.push('unlimited_amount');
        if (txData.value > 10) features.push('high_value');
        if (txData.data && txData.data.includes('095ea7b3')) features.push('function_approve');
        
        return features;
    }
    
    adjustPatternWeights(features, adjustment) {
        features.forEach(feature => {
            const current = this.patterns.get(feature) || 0.5;
            const newWeight = Math.max(0.1, Math.min(0.9, current + adjustment));
            this.patterns.set(feature, newWeight);
        });
    }
    
    // Предсказываем риск на основе обученных паттернов
    predictBasedOnLearning(txData) {
        const features = this.extractFeatures(txData);
        let totalWeight = 0;
        let count = 0;
        
        features.forEach(feature => {
            const weight = this.patterns.get(feature);
            if (weight !== undefined) {
                totalWeight += weight;
                count++;
            }
        });
        
        if (count === 0) return 0.5; // Нейтральный риск если нет данных
        
        const avgRisk = totalWeight / count;
        
        // Конвертируем в уровень риска
        if (avgRisk > 0.7) return 'high';
        if (avgRisk > 0.4) return 'medium';
        return 'low';
    }
}

module.exports = LearningSystem;