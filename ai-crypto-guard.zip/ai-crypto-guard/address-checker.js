// address-checker.js - Проверка репутации Ethereum адресов
// Интеграция с Etherscan API и локальными базами данных scam-адресов

const fs = require('fs').promises;
const path = require('path');

class AddressChecker {
    constructor() {
        this.etherscanApiKey = process.env.ETHERSCAN_API_KEY;
        this.cache = new Map();
        this.cacheFile = path.join(__dirname, 'address-cache.json');
        this.blacklist = new Set();
        this.whitelist = new Set();
        this.knownContracts = new Map();
        
        // Загружаем данные при инициализации
        this.loadCache();
        this.loadLists();
        this.initializeKnownContracts();
    }
    
    // Инициализация известных контрактов
    initializeKnownContracts() {
        // Популярные DEX и протоколы (примеры доверенных контрактов)
        this.knownContracts.set('0x7a250d5630b4cf539739df2c5dacb4c659f2488d'.toLowerCase(), {
            name: 'Uniswap V2 Router',
            type: 'DEX',
            trustScore: 95,
            verified: true
        });
        
        this.knownContracts.set('0xe592427a0aece92de3edee1f18e0157c05861564'.toLowerCase(), {
            name: 'Uniswap V3 Router',
            type: 'DEX',
            trustScore: 95,
            verified: true
        });
        
        this.knownContracts.set('0x68b3465833fb72a70ecdf485e0e4c7bd8665fc45'.toLowerCase(), {
            name: 'Uniswap V3 Universal Router',
            type: 'DEX',
            trustScore: 95,
            verified: true
        });
        
        this.knownContracts.set('0xdef1c0ded9bec7f1a1670819833240f027b25eff'.toLowerCase(), {
            name: '0x Exchange Proxy',
            type: 'DEX Aggregator',
            trustScore: 90,
            verified: true
        });
        
        this.knownContracts.set('0x1111111254eeb25477b68fb85ed929f73a960582'.toLowerCase(), {
            name: '1inch Router',
            type: 'DEX Aggregator',
            trustScore: 90,
            verified: true
        });
        
        // Стейблкоины
        this.knownContracts.set('0xdac17f958d2ee523a2206206994597c13d831ec7'.toLowerCase(), {
            name: 'USDT',
            type: 'Stablecoin',
            trustScore: 95,
            verified: true
        });
        
        this.knownContracts.set('0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'.toLowerCase(), {
            name: 'USDC',
            type: 'Stablecoin',
            trustScore: 95,
            verified: true
        });
        
        this.knownContracts.set('0x6b175474e89094c44da98b954eedeac495271d0f'.toLowerCase(), {
            name: 'DAI',
            type: 'Stablecoin',
            trustScore: 95,
            verified: true
        });
        
        // WETH
        this.knownContracts.set('0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2'.toLowerCase(), {
            name: 'WETH',
            type: 'Wrapped ETH',
            trustScore: 98,
            verified: true
        });
        
        // Lending protocols
        this.knownContracts.set('0x398ec7346dcd622edc5ae82352f02be94c62d119'.toLowerCase(), {
            name: 'Aave Lending Pool',
            type: 'Lending',
            trustScore: 92,
            verified: true
        });
        
        this.knownContracts.set('0x3d9819210a31b4961b30ef54be2aed79b9c9cd3b'.toLowerCase(), {
            name: 'Compound Comptroller',
            type: 'Lending',
            trustScore: 90,
            verified: true
        });
    }
    
    // Загрузка кэша
    async loadCache() {
        try {
            const data = await fs.readFile(this.cacheFile, 'utf8');
            const parsed = JSON.parse(data);
            this.cache = new Map(Object.entries(parsed));
            console.log(`📦 Загружено ${this.cache.size} кэшированных адресов`);
        } catch (error) {
            this.cache = new Map();
        }
    }
    
    // Сохранение кэша
    async saveCache() {
        try {
            const data = Object.fromEntries(this.cache);
            await fs.writeFile(this.cacheFile, JSON.stringify(data, null, 2), 'utf8');
        } catch (error) {
            console.error('❌ Ошибка сохранения кэша адресов:', error.message);
        }
    }
    
    // Загрузка blacklist/whitelist
    async loadLists() {
        try {
            // Чёрный список (scam адреса) - поддержка двух форматов
            const blacklistData = await fs.readFile(
                path.join(__dirname, 'blacklist.json'), 
                'utf8'
            ).catch(() => '{"addresses": []}');
            
            const blacklistParsed = JSON.parse(blacklistData);
            // Поддержка как массива, так и объекта с полем addresses
            const blacklistAddresses = Array.isArray(blacklistParsed) 
                ? blacklistParsed 
                : (blacklistParsed.addresses || []);
            this.blacklist = new Set(blacklistAddresses.map(a => a.toLowerCase()));
            
            // Белый список (доверенные адреса) - аналогично
            const whitelistData = await fs.readFile(
                path.join(__dirname, 'whitelist.json'), 
                'utf8'
            ).catch(() => '{"addresses": []}');
            
            const whitelistParsed = JSON.parse(whitelistData);
            const whitelistAddresses = Array.isArray(whitelistParsed)
                ? whitelistParsed
                : (whitelistParsed.addresses || []);
            this.whitelist = new Set(whitelistAddresses.map(a => a.toLowerCase()));
            
            console.log(`📝 Загружено: ${this.blacklist.size} в blacklist, ${this.whitelist.size} в whitelist`);
        } catch (error) {
            console.log('📭 Списки адресов не найдены');
            this.blacklist = new Set();
            this.whitelist = new Set();
        }
    }
    
    // Обновление scam базы из внешних источников
    async updateScamDatabase() {
        console.log('🔄 Обновление базы scam адресов...');
        
        const ScamDatabaseUpdater = require('./update-scam-db.js');
        const updater = new ScamDatabaseUpdater();
        
        try {
            const result = await updater.update();
            
            // Перезагружаем списки
            await this.loadLists();
            
            return result;
        } catch (error) {
            console.error('❌ Ошибка обновления базы:', error.message);
            throw error;
        }
    }
    
    // Проверка адреса (комплексная)
    async checkAddress(address) {
        const startTime = Date.now();
        const normalizedAddress = address.toLowerCase();
        
        // Проверяем кэш
        if (this.cache.has(normalizedAddress)) {
            const cached = this.cache.get(normalizedAddress);
            // Кэш валиден 24 часа
            if (Date.now() - cached.timestamp < 24 * 60 * 60 * 1000) {
                return { ...cached, fromCache: true };
            }
        }
        
        const result = {
            address: address,
            normalizedAddress: normalizedAddress,
            isValid: this.isValidFormat(address),
            isContract: null,
            isVerified: null,
            isBlacklisted: this.blacklist.has(normalizedAddress),
            isWhitelisted: this.whitelist.has(normalizedAddress),
            knownContract: this.knownContracts.get(normalizedAddress) || null,
            etherscanData: null,
            riskScore: 0,
            riskLevel: 'unknown',
            warnings: [],
            recommendations: [],
            timestamp: Date.now(),
            checkDuration: 0
        };
        
        // Если невалидный формат - сразу возвращаем
        if (!result.isValid) {
            result.riskScore = 100;
            result.riskLevel = 'high';
            result.warnings.push('Неверный формат Ethereum адреса');
            result.recommendations.push('Проверьте правильность адреса');
            result.checkDuration = Date.now() - startTime;
            return result;
        }
        
        // Проверка в чёрном списке
        if (result.isBlacklisted) {
            result.riskScore = 100;
            result.riskLevel = 'high';
            result.warnings.push('🚨 Адрес находится в чёрном списке известных мошенников!');
            result.recommendations.push('НЕ отправляйте средства на этот адрес');
            result.recommendations.push('Это известный scam-адрес');
        }
        
        // Проверка в белом списке
        if (result.isWhitelisted) {
            result.riskScore = Math.min(result.riskScore, 10);
            result.riskLevel = 'low';
            result.warnings = [];
            result.recommendations.push('✅ Адрес в белом списке');
        }
        
        // Проверка известных контрактов
        if (result.knownContract) {
            result.isContract = true;
            result.isVerified = result.knownContract.verified;
            result.riskScore = Math.min(result.riskScore, 100 - result.knownContract.trustScore);
            result.riskLevel = result.knownContract.trustScore > 90 ? 'low' : 'medium';
            result.recommendations.push(`📋 Известный контракт: ${result.knownContract.name} (${result.knownContract.type})`);
        }
        
        // Проверка через Etherscan API (если есть ключ)
        if (this.etherscanApiKey && !result.knownContract) {
            try {
                const etherscanResult = await this.checkEtherscan(address);
                result.etherscanData = etherscanResult;
                
                if (etherscanResult.isContract) {
                    result.isContract = true;
                    result.isVerified = etherscanResult.isVerified;
                    
                    if (!etherscanResult.isVerified) {
                        result.riskScore += 30;
                        result.warnings.push('⚠️ Контракт не верифицирован на Etherscan');
                        result.recommendations.push('Неверифицированные контракты могут быть опасны');
                    }
                    
                    // Проверка возраста контракта
                    if (etherscanResult.creationDate) {
                        const age = Date.now() - new Date(etherscanResult.creationDate).getTime();
                        const ageDays = age / (1000 * 60 * 60 * 24);
                        
                        if (ageDays < 7) {
                            result.riskScore += 40;
                            result.warnings.push(`🚨 Контракт создан менее недели назад (${Math.floor(ageDays)} дней)`);
                            result.recommendations.push('Новые контракты часто используются для scam');
                        } else if (ageDays < 30) {
                            result.riskScore += 20;
                            result.warnings.push(`⚠️ Контракт создан недавно (${Math.floor(ageDays)} дней)`);
                        }
                    }
                } else {
                    result.isContract = false;
                }
                
            } catch (error) {
                console.error('❌ Ошибка проверки Etherscan:', error.message);
            }
        }
        
        // Проверка на специальные адреса
        if (this.isSpecialAddress(normalizedAddress)) {
            result.riskScore = Math.max(result.riskScore, 80);
            result.warnings.push('⚠️ Специальный адрес (burn, нулевой и т.д.)');
        }
        
        // Финальный расчёт уровня риска
        result.riskScore = Math.min(100, Math.max(0, result.riskScore));
        result.riskLevel = this.calculateRiskLevel(result.riskScore);
        
        // Добавляем общие рекомендации
        if (result.riskScore > 50) {
            result.recommendations.push('🔍 Проверьте адрес на Etherscan перед отправкой');
        }
        
        result.checkDuration = Date.now() - startTime;
        
        // Сохраняем в кэш
        this.cache.set(normalizedAddress, result);
        await this.saveCache();
        
        return result;
    }
    
    // Проверка формата адреса
    isValidFormat(address) {
        if (!address || typeof address !== 'string') return false;
        const clean = address.trim();
        if (clean.length !== 42) return false;
        if (!clean.startsWith('0x')) return false;
        return /^[0-9a-fA-F]{40}$/.test(clean.substring(2));
    }
    
    // Проверка через Etherscan API
    async checkEtherscan(address) {
        if (!this.etherscanApiKey) {
            throw new Error('Etherscan API key not configured');
        }
        
        const result = {
            isContract: false,
            isVerified: false,
            creationDate: null,
            creator: null,
            txCount: 0,
            sourceCode: null
        };
        
        try {
            // Проверяем, является ли адрес контрактом
            const codeResponse = await fetch(
                `https://api.etherscan.io/api?module=proxy&action=eth_getCode&address=${address}&tag=latest&apikey=${this.etherscanApiKey}`
            );
            const codeData = await codeResponse.json();
            
            if (codeData.result && codeData.result !== '0x') {
                result.isContract = true;
                
                // Проверяем верификацию контракта
                const contractResponse = await fetch(
                    `https://api.etherscan.io/api?module=contract&action=getsourcecode&address=${address}&apikey=${this.etherscanApiKey}`
                );
                const contractData = await contractResponse.json();
                
                if (contractData.result && contractData.result[0]) {
                    const contractInfo = contractData.result[0];
                    result.isVerified = contractInfo.SourceCode && contractInfo.SourceCode !== '';
                    result.sourceCode = contractInfo.SourceCode;
                    
                    // Получаем информацию о создании контракта
                    const txResponse = await fetch(
                        `https://api.etherscan.io/api?module=account&action=txlist&address=${address}&startblock=0&endblock=99999999&page=1&offset=1&sort=asc&apikey=${this.etherscanApiKey}`
                    );
                    const txData = await txResponse.json();
                    
                    if (txData.result && txData.result.length > 0) {
                        const firstTx = txData.result[0];
                        result.creationDate = new Date(parseInt(firstTx.timeStamp) * 1000).toISOString();
                        result.creator = firstTx.from;
                    }
                }
            }
            
            // Получаем количество транзакций
            const txCountResponse = await fetch(
                `https://api.etherscan.io/api?module=proxy&action=eth_getTransactionCount&address=${address}&tag=latest&apikey=${this.etherscanApiKey}`
            );
            const txCountData = await txCountResponse.json();
            if (txCountData.result) {
                result.txCount = parseInt(txCountData.result, 16);
            }
            
        } catch (error) {
            console.error('Etherscan API error:', error);
        }
        
        return result;
    }
    
    // Проверка на специальные адреса
    isSpecialAddress(address) {
        const specialAddresses = [
            '0x0000000000000000000000000000000000000000', // Нулевой адрес
            '0x000000000000000000000000000000000000dead', // Burn адрес
            '0x0000000000000000000000000000000000000001', // Ещё один burn
            '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee', // ETH placeholder
        ];
        return specialAddresses.includes(address.toLowerCase());
    }
    
    // Расчёт уровня риска
    calculateRiskLevel(score) {
        if (score >= 70) return 'high';
        if (score >= 40) return 'medium';
        return 'low';
    }
    
    // Добавление в чёрный список
    async addToBlacklist(address, reason = '') {
        const normalized = address.toLowerCase();
        this.blacklist.add(normalized);
        await this.saveLists();
        console.log(`⛔ Добавлен в blacklist: ${address} (${reason})`);
    }
    
    // Добавление в белый список
    async addToWhitelist(address, reason = '') {
        const normalized = address.toLowerCase();
        this.whitelist.add(normalized);
        await this.saveLists();
        console.log(`✅ Добавлен в whitelist: ${address} (${reason})`);
    }
    
    // Сохранение списков
    async saveLists() {
        try {
            await fs.writeFile(
                path.join(__dirname, 'blacklist.json'),
                JSON.stringify([...this.blacklist], null, 2)
            );
            await fs.writeFile(
                path.join(__dirname, 'whitelist.json'),
                JSON.stringify([...this.whitelist], null, 2)
            );
        } catch (error) {
            console.error('❌ Ошибка сохранения списков:', error.message);
        }
    }
    
    // Получение статистики
    getStats() {
        return {
            cacheSize: this.cache.size,
            blacklistSize: this.blacklist.size,
            whitelistSize: this.whitelist.size,
            knownContracts: this.knownContracts.size,
            etherscanEnabled: !!this.etherscanApiKey
        };
    }
    
    // Очистка кэша
    async clearCache() {
        this.cache.clear();
        await this.saveCache();
        console.log('🗑️ Кэш адресов очищен');
    }
}

module.exports = AddressChecker;
