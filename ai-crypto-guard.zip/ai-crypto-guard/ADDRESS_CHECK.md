# 📍 Проверка адресов в AI Crypto Guard

## Обзор

AI Crypto Guard включает **многоуровневую систему проверки адресов**:

1. **Базовая проверка формата** - Валидация Ethereum адреса
2. **Проверка по спискам** - Чёрный/белый список
3. **Проверка известных контрактов** - Uniswap, USDT, Aave и т.д.
4. **Etherscan API** - Проверка верификации и возраста контракта
5. **Кэширование** - Ускорение повторных проверок

## 🚀 Быстрый старт

### Проверка адреса через API

```bash
# GET запрос
curl "http://localhost:3000/check-address?address=0x7a250d5630B4cF539739dF2C5dAcb4c659f2488d"

# POST запрос
curl -X POST http://localhost:3000/check-address \
  -H "Content-Type: application/json" \
  -d '{"address": "0x7a250d5630B4cF539739dF2C5dAcb4c659f2488d"}'
```

### Пример ответа

```json
{
  "address": "0x7a250d5630B4cF539739dF2C5dAcb4c659f2488d",
  "normalizedAddress": "0x7a250d5630b4cf539739df2c5dacb4c659f2488d",
  "isValid": true,
  "isContract": true,
  "isVerified": true,
  "isBlacklisted": false,
  "isWhitelisted": false,
  "knownContract": {
    "name": "Uniswap V2 Router",
    "type": "DEX",
    "trustScore": 95,
    "verified": true
  },
  "etherscanData": {
    "isContract": true,
    "isVerified": true,
    "creationDate": "2020-05-01T00:00:00.000Z",
    "creator": "0x...",
    "txCount": 1500000
  },
  "riskScore": 5,
  "riskLevel": "low",
  "warnings": [],
  "recommendations": [
    "✅ Доверенный контракт: Uniswap V2 Router"
  ],
  "timestamp": 1707792000000,
  "checkDuration": 245
}
```

## 📊 Уровни риска

| Риск | Score | Описание |
|------|-------|----------|
| 🟢 Low | 0-39 | Безопасный адрес |
| 🟡 Medium | 40-69 | Требует внимания |
| 🔴 High | 70-100 | Опасный адрес |

## 🔧 Настройка Etherscan API

### Получение API ключа

1. Перейдите на https://etherscan.io/apis
2. Зарегистрируйтесь или войдите
3. Создайте новый API ключ
4. Добавьте в `.env`:

```env
ETHERSCAN_API_KEY=YourEtherscanApiKey
```

### Перезапуск сервера

```bash
npm start
```

## 📋 API Endpoints

### Проверка адреса

```
GET  /check-address?address=0x...
POST /check-address
```

### Статистика проверки адресов

```
GET /address-stats
```

Ответ:
```json
{
  "cacheSize": 150,
  "blacklistSize": 10,
  "whitelistSize": 5,
  "knownContracts": 12,
  "etherscanEnabled": true
}
```

### Управление списками

#### Добавить в чёрный список

```bash
curl -X POST http://localhost:3000/blacklist/add \
  -H "Content-Type: application/json" \
  -d '{
    "address": "0x...",
    "reason": "Known scam contract"
  }'
```

#### Добавить в белый список

```bash
curl -X POST http://localhost:3000/whitelist/add \
  -H "Content-Type: application/json" \
  -d '{
    "address": "0x...",
    "reason": "Verified exchange"
  }'
```

#### Очистить кэш адресов

```bash
curl -X POST http://localhost:3000/clear-address-cache
```

## 🗂️ Файлы данных

### blacklist.json

```json
[
  "0x000000000000000000000000000000000000dead",
  "0x..."
]
```

### whitelist.json

```json
[
  "0x7a250d5630B4cF539739dF2C5dAcb4c659f2488d",
  "0x..."
]
```

### address-cache.json

Автоматически создаётся при первой проверке. Кэш валиден 24 часа.

## 🏷️ Известные контракты

Система включает базу данных популярных контрактов:

| Контракт | Адрес | Trust Score |
|----------|-------|-------------|
| Uniswap V2 Router | 0x7a25...488d | 95 |
| Uniswap V3 Router | 0xe592...e64 | 95 |
| 1inch Router | 0x1111...0582 | 90 |
| 0x Exchange | 0xdef1...eff | 90 |
| USDT | 0xdac1...ec7 | 95 |
| USDC | 0xa0b8...b48 | 95 |
| DAI | 0x6b17...d0f | 95 |
| WETH | 0xc02a...cc2 | 98 |
| Aave Lending | 0x398e...119 | 92 |
| Compound | 0x3d98...45b | 90 |

## 🔍 Как работает проверка

### Алгоритм

1. **Нормализация** - Приведение к нижнему регистру
2. **Валидация формата** - Проверка 0x + 40 hex символов
3. **Кэш** - Проверка в локальном кэше (24 часа)
4. **Чёрный список** - Проверка известных scam
5. **Белый список** - Проверка доверенных
6. **Известные контракты** - Проверка базы данных
7. **Etherscan API** - Проверка верификации и возраста
8. **Расчёт риска** - Итоговый score 0-100

### Факторы риска

| Фактор | Влияние на Score |
|--------|------------------|
| В чёрном списке | +100 (HIGH) |
| Неверифицированный контракт | +30 |
| Контракт < 7 дней | +40 |
| Контракт < 30 дней | +20 |
| В белом списке | -90 |
| Известный контракт (trust > 90) | -80 |

## 💡 Примеры использования

### Пример 1: Проверка Uniswap Router

```bash
curl "http://localhost:3000/check-address?address=0x7a250d5630B4cF539739dF2C5dAcb4c659f2488d" | jq
```

Ожидаемый результат:
```json
{
  "riskScore": 5,
  "riskLevel": "low",
  "knownContract": {
    "name": "Uniswap V2 Router",
    "trustScore": 95
  }
}
```

### Пример 2: Проверка неверифицированного контракта

```bash
curl "http://localhost:3000/check-address?address=0x1234567890123456789012345678901234567890" | jq
```

Ожидаемый результат:
```json
{
  "riskScore": 30,
  "riskLevel": "medium",
  "warnings": [
    "⚠️ Контракт не верифицирован на Etherscan"
  ]
}
```

### Пример 3: Проверка адреса в чёрном списке

```bash
# Сначала добавим в чёрный список
curl -X POST http://localhost:3000/blacklist/add \
  -d '{"address": "0xbad...", "reason": "Scam"}'

# Проверим
curl "http://localhost:3000/check-address?address=0xbad..." | jq
```

Ожидаемый результат:
```json
{
  "riskScore": 100,
  "riskLevel": "high",
  "isBlacklisted": true,
  "warnings": [
    "🚨 Адрес находится в чёрном списке известных мошенников!"
  ]
}
```

## 🌐 Интеграция в анализ транзакций

Проверка адреса **автоматически** выполняется при анализе транзакции:

```bash
curl -X POST http://localhost:3000/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "to": "0x7a250d5630B4cF539739dF2C5dAcb4c659f2488d",
    "value": "1.0"
  }' | jq '.addressCheck'
```

## 📈 Мониторинг

### Статистика в system-info

```bash
curl http://localhost:3000/system-info | jq '.addressCheckerStatus'
```

### Логи сервера

При проверке адреса в консоли:
```
🔍 Проверяем адрес: 0x7a250d5630B4cF539739dF2C5dAcb4c659f2488d
✅ Адрес 0x7a250d5630B4cF539739dF2C5dAcb4c659f2488d прошел базовую проверку
📊 Результат проверки адреса: {
  riskScore: 5,
  riskLevel: 'low',
  isContract: true,
  isVerified: true,
  knownContract: 'Uniswap V2 Router'
}
```

## 🔒 Безопасность

- Кэш хранится локально, не отправляется наружу
- Etherscan API используется только при наличии ключа
- Чёрный/белый список контролируется вами
- Все проверки выполняются локально (кроме Etherscan)

## 🛠️ Расширение функциональности

### Добавить свой контракт в базу

```javascript
// address-checker.js
this.knownContracts.set('0x...'.toLowerCase(), {
  name: 'Your Contract Name',
  type: 'Your Type',
  trustScore: 90,
  verified: true
});
```

### Импорт списка scam адресов

```javascript
// Добавьте в address-checker.js
async loadExternalBlacklist() {
  // Загрузка с cryptoscamdb.org или другого источника
  const response = await fetch('https://api.cryptoscamdb.org/blacklist');
  const data = await response.json();
  data.forEach(addr => this.blacklist.add(addr.toLowerCase()));
}
```

---

**Проверяйте адреса перед отправкой средств! 🔒**
