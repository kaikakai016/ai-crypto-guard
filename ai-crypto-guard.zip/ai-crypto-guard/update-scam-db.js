#!/usr/bin/env node
// update-scam-db.js - Скрипт для обновления базы scam адресов
// Скачивает адреса из различных открытых источников

const fs = require('fs').promises;
const path = require('path');

class ScamDatabaseUpdater {
    constructor() {
        this.dataDir = path.join(__dirname, 'scam-data');
        this.blacklistFile = path.join(__dirname, 'blacklist.json');
        this.combinedFile = path.join(__dirname, 'scam-addresses-combined.json');
        this.scamAddresses = new Set();
        
        // Источники данных
        this.sources = {
            // Основной список известных scam адресов (hardcoded базовый набор)
            knownScams: [
                '0x000000000000000000000000000000000000dead',
                '0x0000000000000000000000000000000000000001',
                '0x0000000000000000000000000000000000000000', // Нулевой адрес для burn
            ],
            
            // URL для скачивания (будут добавлены при наличии API)
            urls: {
                // CryptoScamDB - требует API ключ
                // 'cryptoscamdb': 'https://api.cryptoscamdb.org/v1/blacklist',
                
                // Chainabuse - требует API ключ
                // 'chainabuse': 'https://api.chainabuse.com/v1/reports',
            }
        };
    }
    
    async initialize() {
        console.log('🚀 Инициализация обновления базы scam адресов...');
        
        // Создаём директорию для данных
        try {
            await fs.mkdir(this.dataDir, { recursive: true });
        } catch (e) {
            // Директория уже существует
        }
        
        // Загружаем существующий чёрный список
        await this.loadExistingBlacklist();
        
        // Добавляем базовые известные scam
        this.sources.knownScams.forEach(addr => this.scamAddresses.add(addr.toLowerCase()));
    }
    
    async loadExistingBlacklist() {
        try {
            const data = await fs.readFile(this.blacklistFile, 'utf8');
            const parsed = JSON.parse(data);
            
            // Поддержка двух форматов: массив или объект с полем addresses
            const addresses = Array.isArray(parsed) ? parsed : (parsed.addresses || []);
            
            addresses.forEach(addr => {
                if (this.isValidAddress(addr)) {
                    this.scamAddresses.add(addr.toLowerCase());
                }
            });
            
            console.log(`📥 Загружено ${addresses.length} адресов из существующего blacklist`);
        } catch (error) {
            console.log('📭 Существующий blacklist не найден, создаём новый');
        }
    }
    
    // Добавление популярных scam адресов (обновляемый список)
    addPopularScams() {
        console.log('➕ Добавление известных scam адресов...');
        
        // Этот список можно регулярно обновлять
        const popularScams = [
            // Примеры известных scam адресов (замените на реальные при обновлении)
            '0x1111111111111111111111111111111111111111',
            '0x2222222222222222222222222222222222222222',
        ];
        
        popularScams.forEach(addr => {
            if (this.isValidAddress(addr)) {
                this.scamAddresses.add(addr.toLowerCase());
            }
        });
    }
    
    // Скачивание с CryptoScamDB (если есть API ключ)
    async fetchFromCryptoScamDB() {
        const apiKey = process.env.CRYPTOSCAMDB_API_KEY;
        if (!apiKey) {
            console.log('⚠️  CRYPTOSCAMDB_API_KEY не настроен, пропускаем');
            return 0;
        }
        
        try {
            console.log('🌐 Скачивание с CryptoScamDB...');
            
            const response = await fetch('https://api.cryptoscamdb.org/v1/blacklist', {
                headers: {
                    'Authorization': `Bearer ${apiKey}`
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            const data = await response.json();
            let count = 0;
            
            if (data.result && Array.isArray(data.result)) {
                data.result.forEach(entry => {
                    if (entry.address && this.isValidAddress(entry.address)) {
                        this.scamAddresses.add(entry.address.toLowerCase());
                        count++;
                    }
                });
            }
            
            console.log(`✅ Скачано ${count} адресов с CryptoScamDB`);
            return count;
            
        } catch (error) {
            console.error('❌ Ошибка скачивания с CryptoScamDB:', error.message);
            return 0;
        }
    }
    
    // Скачивание с Chainabuse (если есть API ключ)
    async fetchFromChainabuse() {
        const apiKey = process.env.CHAINABUSE_API_KEY;
        if (!apiKey) {
            console.log('⚠️  CHAINABUSE_API_KEY не настроен, пропускаем');
            return 0;
        }
        
        try {
            console.log('🌐 Скачивание с Chainabuse...');
            
            const response = await fetch('https://api.chainabuse.com/v1/reports?status=confirmed', {
                headers: {
                    'Authorization': `Bearer ${apiKey}`
                }
            });
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            const data = await response.json();
            let count = 0;
            
            if (Array.isArray(data)) {
                data.forEach(report => {
                    if (report.address && this.isValidAddress(report.address)) {
                        this.scamAddresses.add(report.address.toLowerCase());
                        count++;
                    }
                });
            }
            
            console.log(`✅ Скачано ${count} адресов с Chainabuse`);
            return count;
            
        } catch (error) {
            console.error('❌ Ошибка скачивания с Chainabuse:', error.message);
            return 0;
        }
    }
    
    // Скачивание с Etherscan (labeled addresses)
    async fetchFromEtherscan() {
        const apiKey = process.env.ETHERSCAN_API_KEY;
        if (!apiKey) {
            console.log('⚠️  ETHERSCAN_API_KEY не настроен, пропускаем');
            return 0;
        }
        
        try {
            console.log('🌐 Скачивание labeled addresses с Etherscan...');
            
            // Список меток для проверки
            const labels = ['phish-hack', 'exploit', 'heist'];
            let totalCount = 0;
            
            for (const label of labels) {
                try {
                    const response = await fetch(
                        `https://api.etherscan.io/api?module=account&action=txlist&address=0x&page=1&offset=1&apikey=${apiKey}`
                    );
                    
                    // Примечание: Etherscan не предоставляет прямого API для labeled addresses
                    // Это заглушка для будущей реализации
                    
                } catch (e) {
                    console.log(`⚠️  Не удалось получить метку ${label}`);
                }
            }
            
            console.log(`✅ Скачано ${totalCount} адресов с Etherscan`);
            return totalCount;
            
        } catch (error) {
            console.error('❌ Ошибка скачивания с Etherscan:', error.message);
            return 0;
        }
    }
    
    // Загрузка из локального файла (если пользователь добавил свои адреса)
    async loadFromLocalFile() {
        const localFile = path.join(this.dataDir, 'custom-scams.txt');
        
        try {
            const data = await fs.readFile(localFile, 'utf8');
            const lines = data.split('\n');
            let count = 0;
            
            lines.forEach(line => {
                const address = line.trim();
                if (this.isValidAddress(address)) {
                    this.scamAddresses.add(address.toLowerCase());
                    count++;
                }
            });
            
            console.log(`✅ Загружено ${count} адресов из локального файла`);
            return count;
            
        } catch (error) {
            console.log('📭 Локальный файл custom-scams.txt не найден');
            return 0;
        }
    }
    
    // Проверка валидности адреса
    isValidAddress(address) {
        if (!address || typeof address !== 'string') return false;
        const clean = address.trim();
        if (clean.length !== 42) return false;
        if (!clean.startsWith('0x')) return false;
        return /^[0-9a-fA-F]{40}$/.test(clean.substring(2));
    }
    
    // Сохранение обновлённого blacklist
    async saveBlacklist() {
        const addresses = [...this.scamAddresses].sort();
        
        const data = {
            _description: "Чёрный список известных scam/malicious адресов",
            _updated: new Date().toISOString(),
            _count: addresses.length,
            _sources: [
                "CryptoScamDB (https://cryptoscamdb.org/)",
                "Chainabuse (https://chainabuse.com/)",
                "Etherscan Labels (https://etherscan.io/accounts/label/)",
                "Community Reports"
            ],
            addresses: addresses
        };
        
        await fs.writeFile(this.blacklistFile, JSON.stringify(data, null, 2), 'utf8');
        console.log(`💾 Сохранено ${addresses.length} адресов в blacklist.json`);
    }
    
    // Создание объединённого файла для быстрого доступа
    async saveCombinedFile() {
        const data = {
            version: '1.0.0',
            updated: new Date().toISOString(),
            count: this.scamAddresses.size,
            addresses: [...this.scamAddresses].sort()
        };
        
        await fs.writeFile(this.combinedFile, JSON.stringify(data, null, 2), 'utf8');
        console.log(`💾 Создан объединённый файл: ${this.combinedFile}`);
    }
    
    // Создание шаблона для пользовательских адресов
    async createCustomTemplate() {
        const templateFile = path.join(this.dataDir, 'custom-scams.txt');
        
        try {
            await fs.access(templateFile);
        } catch {
            const template = `# Добавьте сюда свои scam адреса (по одному на строку)
# Строки, начинающиеся с #, игнорируются

# Примеры:
# 0x1234567890123456789012345678901234567890
# 0xabcdefabcdefabcdefabcdefabcdefabcdefabcd
`;
            await fs.writeFile(templateFile, template, 'utf8');
            console.log('📝 Создан шаблон custom-scams.txt');
        }
    }
    
    // Основной метод обновления
    async update() {
        console.log('='.repeat(60));
        console.log('🔄 ОБНОВЛЕНИЕ БАЗЫ SCAM АДРЕСОВ');
        console.log('='.repeat(60));
        console.log();
        
        await this.initialize();
        
        console.log();
        console.log('📥 Скачивание данных из источников...');
        console.log('-'.repeat(60));
        
        // Добавляем известные scam
        this.addPopularScams();
        
        // Пробуем скачать из внешних источников
        const stats = {
            cryptoscamdb: await this.fetchFromCryptoScamDB(),
            chainabuse: await this.fetchFromChainabuse(),
            etherscan: await this.fetchFromEtherscan(),
            local: await this.loadFromLocalFile()
        };
        
        console.log();
        console.log('-'.repeat(60));
        console.log('📊 СТАТИСТИКА:');
        console.log(`   Всего уникальных адресов: ${this.scamAddresses.size}`);
        console.log(`   CryptoScamDB: ${stats.cryptoscamdb}`);
        console.log(`   Chainabuse: ${stats.chainabuse}`);
        console.log(`   Etherscan: ${stats.etherscan}`);
        console.log(`   Локальный файл: ${stats.local}`);
        console.log();
        
        // Сохраняем результаты
        await this.saveBlacklist();
        await this.saveCombinedFile();
        await this.createCustomTemplate();
        
        console.log();
        console.log('='.repeat(60));
        console.log('✅ ОБНОВЛЕНИЕ ЗАВЕРШЕНО!');
        console.log('='.repeat(60));
        console.log();
        console.log('💡 Советы:');
        console.log('   • Добавьте свои адреса в scam-data/custom-scams.txt');
        console.log('   • Получите API ключи для автоматического обновления:');
        console.log('     - CryptoScamDB: https://cryptoscamdb.org/');
        console.log('     - Chainabuse: https://chainabuse.com/');
        console.log('   • Запускайте обновление регулярно: node update-scam-db.js');
        console.log();
        
        return {
            total: this.scamAddresses.size,
            stats: stats
        };
    }
    
    // Проверка наличия адреса в базе
    async checkAddress(address) {
        if (!this.isValidAddress(address)) {
            return { valid: false, isScam: false };
        }
        
        const normalized = address.toLowerCase();
        
        // Проверяем в текущем наборе
        if (this.scamAddresses.has(normalized)) {
            return { valid: true, isScam: true, source: 'local' };
        }
        
        // Проверяем в сохранённом файле
        try {
            const data = await fs.readFile(this.blacklistFile, 'utf8');
            const parsed = JSON.parse(data);
            const addresses = parsed.addresses || [];
            
            if (addresses.includes(normalized)) {
                return { valid: true, isScam: true, source: 'blacklist.json' };
            }
        } catch (e) {
            // Файл не найден
        }
        
        return { valid: true, isScam: false };
    }
}

// Если скрипт запущен напрямую
if (require.main === module) {
    const updater = new ScamDatabaseUpdater();
    updater.update().catch(error => {
        console.error('❌ Критическая ошибка:', error);
        process.exit(1);
    });
}

module.exports = ScamDatabaseUpdater;
