// test.js - Тестирование AI Crypto Guard API
const http = require('http');

// Цвета для консоли
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m'
};

// Тестовые транзакции
const testCases = [
  {
    name: 'Unlimited Approve',
    data: {
      type: 'approve',
      amount: 'unlimited',
      to: '0x7a250d5630B4cF539739dF2C5dAcb4c659f2488d',
      spender: '0x7a250d5630B4cF539739dF2C5dAcb4c659f2488d',
      value: '0',
      data: '0x095ea7b30000000000000000000000007a250d5630b4cf539739df2c5dacb4c659f2488dffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'
    },
    expectedRisk: 'high'
  },
  {
    name: 'Token Burn (Zero Address)',
    data: {
      to: '0x0000000000000000000000000000000000000000',
      value: '1.5',
      data: '0x'
    },
    expectedRisk: 'high'
  },
  {
    name: 'Large Transfer',
    data: {
      to: '0x742d35Cc6634C0532925a3b844Bc9e7575f0D5E2',
      value: '15.75',
      data: '0x'
    },
    expectedRisk: 'medium'
  },
  {
    name: 'Safe Transaction',
    data: {
      to: '0x742d35Cc6634C0532925a3b844Bc9e7575f0D5E2',
      value: '0.05',
      data: '0x'
    },
    expectedRisk: 'low'
  },
  {
    name: 'Invalid Address',
    data: {
      to: '0xINVALID',
      value: '1.0',
      data: '0x'
    },
    expectedRisk: 'high'
  },
  {
    name: 'Limited Approve',
    data: {
      type: 'approve',
      amount: '100',
      to: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
      spender: '0x7a250d5630B4cF539739dF2C5dAcb4c659f2488d',
      value: '0'
    },
    expectedRisk: 'medium'
  },
  {
    name: 'NFT Approval (setApprovalForAll)',
    data: {
      to: '0xBC4CA0EdA7647A8aB7C2061c2E118A18a936f13D',
      value: '0',
      data: '0xa22cb4650000000000000000000000007a250d5630b4cf539739df2c5dacb4c659f2488d0000000000000000000000000000000000000000000000000000000000000001'
    },
    expectedRisk: 'medium'
  }
];

// Функция для выполнения POST запроса
function makeRequest(data) {
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify(data);
    
    const options = {
      hostname: 'localhost',
      port: 3000,
      path: '/analyze',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      }
    };
    
    const req = http.request(options, (res) => {
      let responseData = '';
      
      res.on('data', (chunk) => {
        responseData += chunk;
      });
      
      res.on('end', () => {
        try {
          const parsed = JSON.parse(responseData);
          resolve(parsed);
        } catch (e) {
          reject(new Error('Failed to parse response: ' + e.message));
        }
      });
    });
    
    req.on('error', (error) => {
      reject(error);
    });
    
    req.write(postData);
    req.end();
  });
}

// Функция для проверки системы
async function checkSystem() {
  return new Promise((resolve, reject) => {
    http.get('http://localhost:3000/system-info', (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve(parsed);
        } catch (e) {
          reject(e);
        }
      });
    }).on('error', reject);
  });
}

// Главная функция тестирования
async function runTests() {
  console.log(`${colors.cyan}╔════════════════════════════════════════════════════════╗${colors.reset}`);
  console.log(`${colors.cyan}║${colors.reset}     🤖 AI Crypto Guard - Test Suite v1.0              ${colors.cyan}║${colors.reset}`);
  console.log(`${colors.cyan}╚════════════════════════════════════════════════════════╝${colors.reset}`);
  console.log();
  
  // Проверяем, запущен ли сервер
  try {
    const systemInfo = await checkSystem();
    console.log(`${colors.green}✅ Сервер запущен:${colors.reset}`);
    console.log(`   Название: ${systemInfo.name}`);
    console.log(`   Версия: ${systemInfo.version}`);
    console.log(`   AI Включен: ${systemInfo.aiStatus?.enabled || false}`);
    console.log(`   Симуляция: ${systemInfo.aiStatus?.usingSimulation || false}`);
    console.log();
  } catch (error) {
    console.log(`${colors.red}❌ Ошибка: Сервер не запущен на http://localhost:3000${colors.reset}`);
    console.log(`${colors.yellow}   Запустите сервер: npm start${colors.reset}`);
    process.exit(1);
  }
  
  // Запускаем тесты
  let passed = 0;
  let failed = 0;
  
  console.log(`${colors.blue}🧪 Запуск тестов...${colors.reset}`);
  console.log();
  
  for (const testCase of testCases) {
    try {
      process.stdout.write(`${colors.yellow}▶${colors.reset} ${testCase.name}... `);
      
      const result = await makeRequest(testCase.data);
      
      const riskMatch = result.risk === testCase.expectedRisk;
      
      if (riskMatch) {
        console.log(`${colors.green}✅ PASS${colors.reset} (риск: ${result.risk})`);
        passed++;
      } else {
        console.log(`${colors.red}❌ FAIL${colors.reset} (ожидалось: ${testCase.expectedRisk}, получено: ${result.risk})`);
        failed++;
      }
      
      // Выводим рекомендации если есть
      if (result.recommendations && result.recommendations.length > 0) {
        console.log(`   ${colors.cyan}💡${colors.reset} ${result.recommendations[0]}`);
      }
      
      // Выводим AI статус
      if (result.aiAnalysis) {
        const aiSource = result.aiAnalysis.fromOpenAI 
          ? `${colors.green}OpenAI${colors.reset}` 
          : `${colors.yellow}Симуляция${colors.reset}`;
        console.log(`   ${colors.cyan}🤖${colors.reset} AI: ${aiSource}`);
      }
      
    } catch (error) {
      console.log(`${colors.red}❌ ERROR${colors.reset} (${error.message})`);
      failed++;
    }
  }
  
  // Итоги
  console.log();
  console.log(`${colors.cyan}╔════════════════════════════════════════════════════════╗${colors.reset}`);
  console.log(`${colors.cyan}║${colors.reset}                    📊 ИТОГИ ТЕСТОВ                    ${colors.cyan}║${colors.reset}`);
  console.log(`${colors.cyan}╠════════════════════════════════════════════════════════╣${colors.reset}`);
  console.log(`${colors.cyan}║${colors.reset}  ✅ Пройдено: ${passed.toString().padEnd(3)}                                    ${colors.cyan}║${colors.reset}`);
  console.log(`${colors.cyan}║${colors.reset}  ❌ Не пройдено: ${failed.toString().padEnd(3)}                                 ${colors.cyan}║${colors.reset}`);
  console.log(`${colors.cyan}║${colors.reset}  📊 Всего: ${testCases.length.toString().padEnd(3)}                                    ${colors.cyan}║${colors.reset}`);
  console.log(`${colors.cyan}╠════════════════════════════════════════════════════════╣${colors.reset}`);
  
  if (failed === 0) {
    console.log(`${colors.cyan}║${colors.reset}  ${colors.green}🎉 Все тесты пройдены успешно!${colors.reset}                        ${colors.cyan}║${colors.reset}`);
  } else {
    console.log(`${colors.cyan}║${colors.reset}  ${colors.red}⚠️  Есть непройденные тесты${colors.reset}                            ${colors.cyan}║${colors.reset}`);
  }
  
  console.log(`${colors.cyan}╚════════════════════════════════════════════════════════╝${colors.reset}`);
  
  process.exit(failed > 0 ? 1 : 0);
}

// Запускаем тесты
runTests().catch(error => {
  console.error(`${colors.red}❌ Критическая ошибка:${colors.reset}`, error.message);
  process.exit(1);
});
