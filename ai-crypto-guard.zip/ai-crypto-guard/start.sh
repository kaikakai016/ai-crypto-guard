#!/bin/bash

# start.sh - Скрипт запуска AI Crypto Guard

echo "🚀 AI Crypto Guard - Startup Script"
echo "===================================="
echo ""

# Проверка Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js не установлен!"
    echo "   Установите Node.js: https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 14 ]; then
    echo "❌ Требуется Node.js >= 14.0.0"
    echo "   Текущая версия: $(node -v)"
    exit 1
fi

echo "✅ Node.js: $(node -v)"

# Проверка npm
if ! command -v npm &> /dev/null; then
    echo "❌ npm не установлен!"
    exit 1
fi

echo "✅ npm: $(npm -v)"

# Проверка зависимостей
if [ ! -d "node_modules" ]; then
    echo ""
    echo "📦 Установка зависимостей..."
    npm install
    
    if [ $? -ne 0 ]; then
        echo "❌ Ошибка установки зависимостей"
        exit 1
    fi
    
    echo "✅ Зависимости установлены"
fi

# Проверка .env
if [ ! -f ".env" ]; then
    echo ""
    echo "⚠️  Файл .env не найден!"
    echo "   Копируем .env.example → .env"
    cp .env.example .env
    echo "   ✅ Создан .env файл"
    echo "   💡 Отредактируйте .env для настройки OpenAI API ключа"
fi

# Проверка порта
PORT=${PORT:-3000}
if lsof -Pi :$PORT -sTCP:LISTEN -t >/dev/null 2>&1; then
    echo ""
    echo "⚠️  Порт $PORT уже занят!"
    echo "   Останавливаем существующий процесс..."
    kill $(lsof -Pi :$PORT -sTCP:LISTEN -t) 2>/dev/null
    sleep 1
fi

echo ""
echo "🚀 Запуск AI Crypto Guard..."
echo ""
echo "📊 Доступные endpoints:"
echo "   🌐 Веб-интерфейс: http://localhost:$PORT"
echo "   🔍 API анализа:   http://localhost:$PORT/analyze"
echo "   📋 История:       http://localhost:$PORT/history"
echo "   📈 Статистика:    http://localhost:$PORT/stats"
echo "   ℹ️  Система:      http://localhost:$PORT/system-info"
echo ""
echo "🛡️  Chrome Extension:"
echo "   1. Откройте chrome://extensions/"
echo "   2. Включите 'Режим разработчика'"
echo "   3. Нажмите 'Загрузить распакованное'"
echo "   4. Выберите папку 'extension/'"
echo ""
echo "===================================="
echo ""

# Запуск сервера
node index.js
