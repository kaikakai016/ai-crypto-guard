// database.js
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Подключаемся к БД (файл создастся автоматически)
const db = new sqlite3.Database(path.join(__dirname, 'transactions.db'));

// Создаем таблицу, если её нет
db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            tx_data TEXT,
            risk_level TEXT,
            explanation TEXT,
            ip_address TEXT
        )
    `, (err) => {
        if (err) {
            console.error('❌ Ошибка создания таблицы:', err.message);
        } else {
            console.log('✅ База данных готова');
        }
    });
});

// Функция для сохранения транзакции
function saveTransaction(txData, risk, explanation, ip = 'localhost') {
    return new Promise((resolve, reject) => {
        db.run(
            `INSERT INTO transactions (tx_data, risk_level, explanation, ip_address) 
             VALUES (?, ?, ?, ?)`,
            [JSON.stringify(txData), risk, explanation, ip],
            function(err) {
                if (err) {
                    console.error('❌ Ошибка сохранения транзакции:', err.message);
                    reject(err);
                } else {
                    console.log(`✅ Транзакция #${this.lastID} сохранена в БД`);
                    resolve(this.lastID);
                }
            }
        );
    });
}

// Функция для получения истории
function getHistory(limit = 10) {
    return new Promise((resolve, reject) => {
        db.all(
            `SELECT * FROM transactions 
             ORDER BY timestamp DESC 
             LIMIT ?`,
            [limit],
            (err, rows) => {
                if (err) {
                    console.error('❌ Ошибка получения истории:', err.message);
                    reject(err);
                } else {
                    resolve(rows);
                }
            }
        );
    });
}

// Функция для статистики
function getStats() {
    return new Promise((resolve, reject) => {
        db.all(
            `SELECT 
                risk_level,
                COUNT(*) as count
             FROM transactions 
             GROUP BY risk_level
             ORDER BY count DESC`,
            (err, rows) => {
                if (err) {
                    console.error('❌ Ошибка получения статистики:', err.message);
                    reject(err);
                } else {
                    resolve(rows);
                }
            }
        );
    });
}

// Функция для получения последних N транзакций
function getRecentTransactions(limit = 5) {
    return new Promise((resolve, reject) => {
        db.all(
            `SELECT 
                id,
                timestamp,
                risk_level,
                explanation
             FROM transactions 
             ORDER BY timestamp DESC 
             LIMIT ?`,
            [limit],
            (err, rows) => {
                if (err) {
                    reject(err);
                } else {
                    resolve(rows);
                }
            }
        );
    });
}

module.exports = {
    saveTransaction,
    getHistory,
    getStats,
    getRecentTransactions
};