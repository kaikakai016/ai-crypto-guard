# 🤖 Настройка OpenRouter для AI Crypto Guard

## Что такое OpenRouter?

**OpenRouter** — это единый API для доступа к различным AI моделям:
- **Anthropic Claude** (Claude 3.5 Sonnet, Claude 3 Opus)
- **OpenAI** (GPT-4, GPT-3.5 Turbo)
- **Meta** (Llama 3.1, Llama 3)
- **Google** (Gemini)
- И многие другие!

**Преимущества:**
- 🎯 Один API ключ для всех моделей
- 💰 Часто дешевле прямого доступа
- 🔄 Легко переключаться между моделями
- 📊 Единый биллинг

## 🚀 Быстрая настройка

### Шаг 1: Получение API ключа

1. Перейдите на https://openrouter.ai/keys
2. Зарегистрируйтесь или войдите
3. Нажмите **"Create Key"**
4. Скопируйте ключ (начинается с `sk-or-v1-`)

### Шаг 2: Настройка .env

```bash
# Откройте .env файл
nano .env
```

Добавьте:
```env
OPENROUTER_API_KEY=sk-or-v1-your-actual-key-here
AI_MODEL=anthropic/claude-3.5-sonnet
APP_URL=http://localhost:3000
```

### Шаг 3: Перезапуск

```bash
npm start
```

## 📊 Доступные модели

### Рекомендуемые модели для анализа транзакций

| Модель | ID | Цена (вход/выход) | Рекомендация |
|--------|-----|-------------------|--------------|
| **Claude 3.5 Sonnet** | `anthropic/claude-3.5-sonnet` | $3/$15 за 1M | ⭐ Лучший выбор |
| GPT-4 Turbo | `openai/gpt-4-turbo` | $10/$30 за 1M | Хороший выбор |
| GPT-3.5 Turbo | `openai/gpt-3.5-turbo` | $0.5/$1.5 за 1M | Бюджетный |
| Llama 3.1 70B | `meta-llama/llama-3.1-70b-instruct` | $0.9/$0.9 за 1M | Бесплатная альтернатива |

### Бесплатные модели

OpenRouter предлагает **бесплатный доступ** к некоторым моделям с ограничениями:

```env
# Бесплатная модель (с rate limiting)
AI_MODEL=mistralai/mistral-7b-instruct:free
```

## 💰 Стоимость

### Расчёт для AI Crypto Guard

Один анализ транзакции:
- Вход: ~500 tokens
- Выход: ~200 tokens

**Claude 3.5 Sonnet:**
```
(500 * $3 + 200 * $15) / 1,000,000 = $0.0045 за анализ
```

**10,000 анализов = ~$45**

### Сравнение цен

| Провайдер | Модель | Цена за 10K анализов |
|-----------|--------|---------------------|
| OpenAI | GPT-4 | ~$110 |
| OpenRouter | Claude 3.5 | ~$45 |
| OpenRouter | GPT-3.5 | ~$7 |
| OpenRouter | Llama 3.1 70B | ~$13.50 |

## 🔧 Расширенная настройка

### Переключение модели

Просто измените `AI_MODEL` в `.env`:

```env
# Для Claude 3 Opus (максимальная точность)
AI_MODEL=anthropic/claude-3-opus

# Для GPT-4
AI_MODEL=openai/gpt-4

# Для бюджетного варианта
AI_MODEL=openai/gpt-3.5-turbo
```

### Проверка доступных моделей

```bash
# Получить список моделей через API
curl https://openrouter.ai/api/v1/models \
  -H "Authorization: Bearer $OPENROUTER_API_KEY"
```

## 🧪 Тестирование

### Проверка подключения

```bash
# Запустите тест
curl -X POST http://localhost:3000/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "to": "0x742d35Cc6634C0532925a3b844Bc9e",
    "value": "1.5",
    "data": "0x095ea7b3ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
  }' | jq '.aiAnalysis'
```

### Ожидаемый ответ

```json
{
  "risk": "high",
  "confidence": 0.95,
  "category": "token_approval",
  "explanation": "Обнаружен неограниченный доступ к токенам...",
  "fromOpenRouter": true,
  "model": "anthropic/claude-3.5-sonnet"
}
```

## 🔍 Мониторинг использования

### В консоли сервера

При анализе транзакции:
```
🤖 Отправляем запрос к OpenRouter...
✅ AI анализ завершен через OpenRouter
```

### Проверка статуса

```bash
curl http://localhost:3000/system-info | jq '.aiStatus'
```

Ответ:
```json
{
  "enabled": true,
  "usingSimulation": false,
  "cacheSize": 150,
  "model": "anthropic/claude-3.5-sonnet"
}
```

## 🛠️ Устранение неполадок

### Ошибка "Invalid API key"

```
❌ Ошибка AI анализа: Invalid API key
```

**Решение:**
1. Проверьте ключ в `.env`
2. Убедитесь, что ключ начинается с `sk-or-v1-`
3. Перезапустите сервер

### Ошибка "Rate limit exceeded"

```
❌ Ошибка AI анализа: Rate limit exceeded
```

**Решение:**
1. Подождите немного
2. Используйте кэширование (включено по умолчанию)
3. Рассмотрите платный тариф

### Модель недоступна

```
❌ Ошибка AI анализа: Model not found
```

**Решение:**
1. Проверьте ID модели на https://openrouter.ai/models
2. Используйте актуальную модель

## 🔄 Fallback к симуляции

Если OpenRouter недоступен:
1. Система **автоматически** переключается на симуляцию
2. Все проверки безопасности продолжают работать
3. В ответе будет `simulated: true`

## 📊 Сравнение с OpenAI

| Параметр | OpenAI | OpenRouter |
|----------|--------|------------|
| API ключ | `sk-...` | `sk-or-v1-...` |
| Модели | Только OpenAI | 50+ моделей |
| Цена | Стандартная | Часто дешевле |
| Переключение | Сложно | Просто (изменить .env) |

## 🎯 Рекомендации

### Для разработки:
- Используйте **симуляцию** или **бесплатные модели**
- Тестируйте без затрат

### Для production:
- **Claude 3.5 Sonnet** — лучшее соотношение цена/качество
- Включите **кэширование**
- Настройте **мониторинг**

### Для экономии:
- **GPT-3.5 Turbo** — дешёвый и быстрый
- **Llama 3.1 70B** — хорошая бесплатная альтернатива

## 📞 Поддержка

- **OpenRouter Docs:** https://openrouter.ai/docs
- **Модели:** https://openrouter.ai/models
- **Discord:** https://discord.gg/openrouter

---

**OpenRouter делает AI анализ доступным и гибким! 🚀**
