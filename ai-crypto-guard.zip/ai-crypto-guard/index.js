const express = require("express");
const db = require("./database.js");
require('dotenv').config();

// Импортируем AI анализатор, систему обучения и проверку адресов
const AIAnalyzer = require('./ai-analyzer.js');
const LearningSystem = require('./learning-system.js');
const AdvancedTransactionAnalyzer = require('./advanced-analyzer.js');
const AddressChecker = require('./address-checker.js');

const app = express();
app.use(express.json());

// Инициализация AI анализатора
const aiAnalyzer = new AIAnalyzer();

// Инициализация системы обучения
const learningSystem = new LearningSystem();

// Инициализация продвинутого анализатора
const advancedAnalyzer = new AdvancedTransactionAnalyzer();

// Инициализация проверки адресов
const addressChecker = new AddressChecker();

// Вспомогательные функции для проверок

// Проверка валидности Ethereum адреса (упрощенная версия)
function isValidEthereumAddress(address) {
    if (!address || typeof address !== 'string') {
        console.log('❌ Адрес пустой или не строка:', address);
        return false;
    }
    
    // Убираем пробелы в начале и конце
    const cleanAddress = address.trim();
    
    // Базовые проверки
    if (cleanAddress.length !== 42) {
        console.log(`❌ Длина адреса не 42 символа: ${cleanAddress.length} символов`);
        return false;
    }
    
    if (!cleanAddress.startsWith('0x')) {
        console.log('❌ Адрес не начинается с 0x');
        return false;
    }
    
    // Проверяем, что после 0x идут только hex символы
    const hexPart = cleanAddress.substring(2);
    const hexRegex = /^[0-9a-fA-F]+$/;
    
    if (!hexRegex.test(hexPart)) {
        console.log('❌ Адрес содержит не-hex символы');
        return false;
    }
    
    console.log(`✅ Адрес валиден: ${cleanAddress.substring(0, 10)}...`);
    return true;
}

// Декодирование данных транзакции
function decodeTransactionData(txData) {
    const decoded = {
        function: null,
        params: {},
        warnings: []
    };
    
    if (!txData || txData === '0x' || txData.length < 10) {
        return decoded;
    }
    
    const data = txData.toLowerCase();
    const functionSignature = data.substring(0, 10);
    
    // Сигнатуры функций ERC-20
    const functionSignatures = {
        '0x095ea7b3': 'approve',
        '0xa9059cbb': 'transfer',
        '0x23b872dd': 'transferFrom',
        '0x70a08231': 'balanceOf',
        '0xdd62ed3e': 'allowance',
        '0x095ea7b3': 'approve',
        '0x1ffc9a7a': 'supportsInterface',
        '0x01ffc9a7': 'supportsInterface',
        '0x42842e0e': 'safeTransferFrom',
        '0xb88d4fde': 'safeTransferFromWithData',
        '0xa22cb465': 'setApprovalForAll',
        '0x2f745c59': 'setApprovalForAll'
    };
    
    decoded.function = functionSignatures[functionSignature] || 'unknown';
    
    // Декодируем параметры для approve
    if (functionSignature === '0x095ea7b3' && data.length >= 138) {
        // approve(address spender, uint256 amount)
        const spender = '0x' + data.substring(34, 74);
        const amount = '0x' + data.substring(74, 138);
        
        decoded.params.spender = spender;
        decoded.params.amount = amount;
        
        // Проверка на unlimited approve
        if (amount === '0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff') {
            decoded.params.isUnlimited = true;
            decoded.warnings.push('🚨 UNLIMITED APPROVE - неограниченный доступ к токенам!');
        } else {
            decoded.params.isUnlimited = false;
            // Конвертируем amount в читаемый формат
            try {
                const amountBigInt = BigInt(amount);
                decoded.params.amountDecimal = amountBigInt.toString();
            } catch (e) {
                decoded.params.amountDecimal = amount;
            }
        }
    }
    
    // Декодируем параметры для transfer
    if (functionSignature === '0xa9059cbb' && data.length >= 138) {
        // transfer(address to, uint256 amount)
        const to = '0x' + data.substring(34, 74);
        const amount = '0x' + data.substring(74, 138);
        
        decoded.params.to = to;
        decoded.params.amount = amount;
        
        try {
            const amountBigInt = BigInt(amount);
            decoded.params.amountDecimal = amountBigInt.toString();
        } catch (e) {
            decoded.params.amountDecimal = amount;
        }
    }
    
    // Декодируем параметры для transferFrom
    if (functionSignature === '0x23b872dd' && data.length >= 202) {
        // transferFrom(address from, address to, uint256 amount)
        const from = '0x' + data.substring(34, 74);
        const to = '0x' + data.substring(98, 138);
        const amount = '0x' + data.substring(138, 202);
        
        decoded.params.from = from;
        decoded.params.to = to;
        decoded.params.amount = amount;
        
        decoded.warnings.push('⚠️ transferFrom - перевод от имени другого адреса');
    }
    
    return decoded;
}

// Проверка на известные scam паттерны в данных транзакции
function checkForScamPatterns(txData) {
    const redFlags = [];
    
    // Проверка подозрительных функций в data поле
    if (txData.data) {
        const data = txData.data.toLowerCase();
        
        // Проверяем функции
        if (data.includes('095ea7b3')) {
            redFlags.push('Вызов функции: approve');
        }
        if (data.includes('a9059cbb')) {
            redFlags.push('Вызов функции: transfer');
        }
        if (data.includes('23b872dd')) {
            redFlags.push('Вызов функции: transferFrom');
        }
        if (data.includes('42842e0e') || data.includes('b88d4fde')) {
            redFlags.push('Вызов функции: safeTransferFrom (NFT)');
        }
        if (data.includes('a22cb465')) {
            redFlags.push('Вызов функции: setApprovalForAll (NFT)');
        }
        
        // Проверка на подозрительные паттерны
        const suspiciousPatterns = [
            { pattern: /airdrop/i, message: 'Упоминание airdrop в данных' },
            { pattern: /reward/i, message: 'Упоминание reward в данных' },
            { pattern: /claim/i, message: 'Упоминание claim в данных' },
            { pattern: /free/i, message: 'Упоминание "free" в данных' }
        ];
        
        suspiciousPatterns.forEach(({ pattern, message }) => {
            if (pattern.test(data)) {
                redFlags.push(message);
            }
        });
    }
    
    return redFlags;
}

// Проверка разумности значения (value)
function isReasonableValue(value, txType) {
    if (!value) return true;
    
    const numValue = parseFloat(value);
    if (isNaN(numValue)) return true;
    
    // Для approve проверяем лимиты
    if (txType === 'approve') {
        if (numValue > 1000000) { // Больше 1 миллиона токенов
            return false;
        }
    }
    
    // Для transfer проверяем разумность суммы
    if (txType === 'transfer' || !txType) {
        if (numValue > 100) { // Больше 100 ETH
            return false;
        }
    }
    
    return true;
}

// Простая и надёжная проверка данных транзакции
function analyzeTransactionData(txData) {
    const warnings = [];
    const decoded = decodeTransactionData(txData.data);
    
    if (!txData.data) {
        console.log('📭 Поле data отсутствует');
        return { warnings, decoded };
    }
    
    const data = txData.data.toLowerCase();
    console.log('🔍 Анализ данных транзакции:');
    console.log('Длина:', data.length, 'символов');
    console.log('Функция:', decoded.function || 'unknown');
    
    // Добавляем предупреждения от декодирования
    if (decoded.warnings.length > 0) {
        warnings.push(...decoded.warnings);
    }
    
    // Проверка на unlimited approve
    if (decoded.params.isUnlimited) {
        console.log('🚨 ОБНАРУЖЕН UNLIMITED APPROVE!');
        warnings.push('🚨 ВНИМАНИЕ: UNLIMITED APPROVE - неограниченный доступ к токенам!');
        warnings.push('⚠️ Контракт получит доступ ко ВСЕМ вашим токенам этого типа');
    }
    
    // Проверка других функций
    if (data.includes('a9059cbb')) {
        console.log('✅ ОБНАРУЖЕНА ФУНКЦИЯ: transfer');
        warnings.push('Обнаружена функция transfer - перевод токенов');
    }
    
    if (data.includes('23b872dd')) {
        console.log('✅ ОБНАРУЖЕНА ФУНКЦИЯ: transferFrom');
        warnings.push('Обнаружена функция transferFrom - перевод от имени другого адреса');
    }
    
    if (data.includes('42842e0e') || data.includes('b88d4fde')) {
        console.log('✅ ОБНАРУЖЕНА ФУНКЦИЯ: safeTransferFrom (NFT)');
        warnings.push('Обнаружена функция safeTransferFrom - перевод NFT');
    }
    
    if (data.includes('a22cb465')) {
        console.log('✅ ОБНАРУЖЕНА ФУНКЦИЯ: setApprovalForAll (NFT)');
        warnings.push('Обнаружена функция setApprovalForAll - разрешение на все NFT коллекции');
    }
    
    console.log('📊 Найдено предупреждений:', warnings.length);
    return { warnings, decoded };
}

// Проверка на нетипичные/подозрительные значения
function checkSuspiciousValues(tx) {
    const warnings = [];
    
    // Проверка очень круглых сумм (часто используются в фишинге)
    if (tx.value) {
        const value = parseFloat(tx.value);
        if (!isNaN(value)) {
            // Проверяем, является ли сумма "круглой"
            if (value === 1 || value === 10 || value === 100 || value === 1000) {
                warnings.push('Сумма ' + value + ' ETH - очень круглая, будьте осторожны');
            }
            
            // Проверка очень маленьких сумм (может быть dust attack)
            if (value < 0.0001) {
                warnings.push('Очень маленькая сумма: ' + value + ' ETH (возможен dust attack)');
            }
            
            // Проверка на фронтраннинг (очень высокий газ)
            if (tx.gasPrice && parseFloat(tx.gasPrice) > 200) {
                warnings.push('🚨 Очень высокая комиссия газа: ' + tx.gasPrice + ' Gwei (возможен фронтраннинг)');
            }
        }
    }
    
    // Проверка газа (если указан)
    if (tx.gas) {
        const gas = parseInt(tx.gas);
        if (!isNaN(gas)) {
            // Стандартный лимит газа для простых транзакций ~21000
            // Для вызовов контрактов может быть больше
            if (gas > 1000000) {
                warnings.push('Очень большой лимит газа: ' + gas + ' (стандартно ~21000-300000)');
            }
        }
    }
    
    return warnings;
}

// CORS для расширения/локалки
app.use(function(req, res, next) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
  if (req.method === "OPTIONS") return res.sendStatus(200);
  next();
});

app.use(express.static("public"));

// Основной endpoint для анализа
app.post("/analyze", async function(req, res) {
  const tx = req.body;
  
  // Получаем IP пользователя (для статистики)
  const ip = req.ip || req.headers['x-forwarded-for'] || req.connection.remoteAddress;

  // Начальные значения
  let risk = "low";
  let message = "Транзакция выглядит безопасно.";
  let recommendations = [];
  let decodedData = null;

  // === ОСНОВНЫЕ ПРОВЕРКИ ===
  
  // 1. Проверка на пустую транзакцию
  if (!tx || Object.keys(tx).length === 0) {
    risk = "medium";
    message = "Транзакция пустая или неверный формат";
    recommendations.push("Проверьте данные транзакции");
  }
  // 2. Проверка unlimited approve (опасно!)
  else if (tx.type === "approve" && tx.amount === "unlimited") {
    risk = "high";
    message = "⚠️ ВНИМАНИЕ: Неограниченный доступ к токенам!";
    recommendations.push("Используйте лимитированный approve (с лимитом суммы)");
    recommendations.push("Проверьте контракт на сайте типа Etherscan");
    recommendations.push("Давайте доступ только проверенным контрактам");
  }
  // 3. Проверка approve с обычной суммой (средний риск)
  else if (tx.type === "approve" && tx.amount !== "unlimited") {
    risk = "medium";
    message = "Выдаётся доступ к токенам";
    recommendations.push("Убедитесь, что доверяете этому контракту");
    recommendations.push("Можно установить лимит по времени");
  }
  // 4. Проверка отправки на нулевой адрес (burn)
  else if (tx.to === "0x0000000000000000000000000000000000000000") {
    risk = "high";
    message = "⚠️ Отправка на нулевой адрес (сожжение токенов)!";
    recommendations.push("Это навсегда уничтожит токены");
    recommendations.push("Убедитесь, что это действительно нужно");
  }
  // 5. Проверка больших сумм (если есть поле value)
  else if (tx.value && parseFloat(tx.value) > 5) {
    risk = "medium";
    message = "Крупная сумма транзакции";
    recommendations.push("Дважды проверьте адрес получателя");
    recommendations.push("Можно отправить сначала маленькую сумму");
  }

  // === ДОПОЛНИТЕЛЬНЫЕ ПРОВЕРКИ ===
  
  // 6. ПРОВЕРКА АДРЕСА ПОЛУЧАТЕЛЯ (комплексная)
  let addressCheckResult = null;
  if (tx.to) {
    console.log('🔍 Проверяем адрес: ' + tx.to);
    
    // Базовая проверка формата
    if (!isValidEthereumAddress(tx.to)) {
        risk = "high";
        message = "⚠️ Неверный формат Ethereum адреса получателя!";
        recommendations.push('Адрес "' + tx.to.substring(0, 20) + '..." имеет неверный формат');
        recommendations.push("Правильный Ethereum адрес должен:");
        recommendations.push("- Начинаться с 0x");
        recommendations.push("- Содержать ровно 42 символа");
        recommendations.push("- Содержать только цифры 0-9 и буквы a-f (не чувствителен к регистру)");
        recommendations.push("Пример: 0x742d35Cc6634C0532925a3b844Bc9e");
    } else {
        console.log('✅ Адрес ' + tx.to + ' прошел базовую проверку');
        
        // Расширенная проверка через AddressChecker
        try {
            addressCheckResult = await addressChecker.checkAddress(tx.to);
            console.log('📊 Результат проверки адреса:', {
                riskScore: addressCheckResult.riskScore,
                riskLevel: addressCheckResult.riskLevel,
                isContract: addressCheckResult.isContract,
                isVerified: addressCheckResult.isVerified,
                isBlacklisted: addressCheckResult.isBlacklisted,
                knownContract: addressCheckResult.knownContract?.name || null
            });
            
            // Если адрес в чёрном списке - ВЫСОКИЙ риск
            if (addressCheckResult.isBlacklisted) {
                risk = "high";
                message = "🚨 ОПАСНО: Адрес находится в чёрном списке известных мошенников!";
                recommendations.push(...addressCheckResult.recommendations);
            }
            // Если известный доверенный контракт - снижаем риск
            else if (addressCheckResult.knownContract && addressCheckResult.knownContract.trustScore > 90) {
                if (risk === "high") risk = "medium";
                recommendations.push(`✅ Доверенный контракт: ${addressCheckResult.knownContract.name}`);
            }
            // Если неверифицированный контракт - повышаем риск
            else if (addressCheckResult.isContract && !addressCheckResult.isVerified) {
                if (risk !== "high") risk = "medium";
                recommendations.push('⚠️ Контракт не верифицирован на Etherscan');
                recommendations.push('Неверифицированные контракты могут содержать вредоносный код');
            }
            // Если новый контракт - предупреждаем
            else if (addressCheckResult.etherscanData?.creationDate) {
                const age = Date.now() - new Date(addressCheckResult.etherscanData.creationDate).getTime();
                const ageDays = age / (1000 * 60 * 60 * 24);
                if (ageDays < 7) {
                    if (risk !== "high") risk = "medium";
                    recommendations.push(`⚠️ Контракт создан недавно (${Math.floor(ageDays)} дней назад)`);
                }
            }
            
            // Добавляем предупреждения от проверки адреса
            if (addressCheckResult.warnings.length > 0) {
                recommendations.push(...addressCheckResult.warnings);
            }
            
        } catch (error) {
            console.error('❌ Ошибка проверки адреса:', error.message);
        }
    }
  }
  
  // 7. Проверка газа (если есть поле gasPrice или maxFeePerGas)
  if ((tx.gasPrice && parseFloat(tx.gasPrice) > 100) || 
      (tx.maxFeePerGas && parseFloat(tx.maxFeePerGas) > 100)) {
    if (risk !== "high") risk = "medium";
    message += " Заметили высокую комиссию газа.";
    recommendations.push("Проверьте актуальную цену газа на sites like Etherscan Gas Tracker");
    recommendations.push("Высокий газ может быть признаком мошенничества");
  }
  
  // 8. Проверка известных scam-адресов (базовый список)
  const scamAddresses = [
    "0x000000000000000000000000000000000000dead", // Известный burn адрес
    "0x0000000000000000000000000000000000000001", // Ещё один
  ];
  
  if (tx.to && scamAddresses.includes(tx.to.toLowerCase())) {
    risk = "high";
    message = "🚨 ОПАСНО: Известный scam-адрес!";
    recommendations.push("НЕ отправляйте средства на этот адрес");
    recommendations.push("Этот адрес находится в чёрном списке мошенников");
  }

  // 9. Проверка на scam паттерны в данных
  const scamPatterns = checkForScamPatterns(tx);
  if (scamPatterns.length > 0) {
    if (risk !== "high") risk = "medium";
    message += " Обнаружены подозрительные паттерны в данных транзакции.";
    recommendations.push("Транзакция содержит вызовы функций, которые часто используют мошенники");
    scamPatterns.forEach(function(pattern) {
        recommendations.push('Паттерн: ' + pattern);
    });
  }
  
  // 10. Проверка разумности суммы
  if (!isReasonableValue(tx.value, tx.type)) {
    if (risk !== "high") risk = "medium";
    message += " Сумма транзакции кажется неразумно большой.";
    recommendations.push("Проверьте правильность указанной суммы");
    recommendations.push("Такие большие суммы часто являются ошибкой или мошенничеством");
  }
  
  // 11. ДЕТАЛЬНАЯ проверка данных транзакции
  let dataWarnings = [];
  if (tx.data) {
    console.log('='.repeat(50));
    console.log('🔍 ПРОВЕРКА ДАННЫХ ТРАНЗАКЦИИ');
    
    const dataAnalysis = analyzeTransactionData(tx);
    dataWarnings = dataAnalysis.warnings;
    decodedData = dataAnalysis.decoded;
    
    if (dataWarnings.length > 0) {
      console.log('⚠️ Предупреждения:', dataWarnings);
      
      // Если обнаружен unlimited approve - ВЫСОКИЙ риск
      const hasUnlimitedApprove = dataWarnings.some(function(w) {
        return w.includes('UNLIMITED APPROVE') || w.includes('неограниченный доступ');
      });
      
      if (hasUnlimitedApprove) {
        risk = "high";
        message = "🚨 ОПАСНО: Обнаружен неограниченный доступ к токенам (unlimited approve)!";
      }
      
      // Добавляем все предупреждения как рекомендации
      dataWarnings.forEach(function(warning) {
        if (!recommendations.includes(warning)) {
          recommendations.push(warning);
        }
      });
    }
    
    console.log('🔍 КОНЕЦ ПРОВЕРКИ ДАННЫХ');
    console.log('='.repeat(50));
  }
  
  // 12. Проверка подозрительных значений
  let valueWarnings = [];
  valueWarnings = checkSuspiciousValues(tx);
  if (valueWarnings.length > 0) {
    console.log('⚠️ Подозрительные значения:', valueWarnings);
    
    if (risk === "low") risk = "medium";
    if (!message.includes("Подозрительные значения")) {
      message += " Обнаружены подозрительные значения.";
    }
    
    valueWarnings.forEach(function(warning) {
      recommendations.push(warning);
    });
  }

  // === AI АНАЛИЗ ===
  let aiResult = null;
  
  try {
    console.log('🤖 Запускаем AI анализ...');
    aiResult = await aiAnalyzer.analyzeTransaction(tx);
    
    console.log('📊 Результат AI:', {
      риск: aiResult.risk,
      категория: aiResult.category,
      предупреждения: aiResult.red_flags?.length || 0,
      fromOpenAI: aiResult.fromOpenAI,
      fromCache: aiResult.fromCache
    });
    
    // Если AI говорит о более высоком риске - обновляем
    const riskLevels = { 'high': 3, 'medium': 2, 'low': 1, 'unknown': 0 };
    const currentRiskLevel = riskLevels[risk] || 0;
    const aiRiskLevel = riskLevels[aiResult.risk] || 0;
    
    if (aiRiskLevel > currentRiskLevel) {
      risk = aiResult.risk;
      message = `🤖 AI: ${aiResult.explanation}`;
      
      // Добавляем рекомендации от AI
      if (aiResult.recommendations && aiResult.recommendations.length > 0) {
        aiResult.recommendations.forEach(rec => {
          if (!recommendations.includes(rec)) {
            recommendations.push(rec);
          }
        });
      }
    }
    
  } catch (error) {
    console.error('❌ Ошибка AI анализа:', error.message);
    aiResult = { error: error.message, fromOpenAI: false };
  }

  // === ПРОДВИНУТЫЙ АНАЛИЗ ===
  let advancedResult = null;
  try {
    console.log('🔬 Запускаем продвинутый анализ...');
    advancedResult = await advancedAnalyzer.analyzeSemantics(tx);
    
    // Конвертируем риск-скор в уровень
    const advancedRisk = advancedAnalyzer.convertToRiskLevel(advancedResult);
    
    // Если продвинутый анализ показывает более высокий риск
    const riskLevels = { 'high': 3, 'medium': 2, 'low': 1 };
    if (riskLevels[advancedRisk] > riskLevels[risk]) {
      risk = advancedRisk;
      message += ` (Advanced: ${advancedResult.warnings.join(', ')})`;
    }
    
    // Добавляем рекомендации от продвинутого анализатора
    const advancedRecs = advancedAnalyzer.generateRecommendations(advancedResult, tx);
    advancedRecs.forEach(rec => {
      if (!recommendations.includes(rec)) {
        recommendations.push(rec);
      }
    });
    
  } catch (error) {
    console.error('❌ Ошибка продвинутого анализа:', error.message);
  }

  // === СИСТЕМА ОБУЧЕНИЯ ===
  let learningResult = null;
  try {
    console.log('🧠 Проверяем паттерны обучения...');
    learningResult = learningSystem.predictBasedOnLearning(tx);
    
    if (learningResult && learningResult !== 'unknown') {
      const riskLevels = { 'high': 3, 'medium': 2, 'low': 1 };
      if (riskLevels[learningResult] > riskLevels[risk]) {
        risk = learningResult;
        message += ' (Обнаружен похожий паттерн в истории)';
      }
    }
  } catch (error) {
    console.error('❌ Ошибка системы обучения:', error.message);
  }

  // Сохраняем транзакцию в БД
  try {
    const txToSave = {
      ...tx,
      ai_analysis: aiResult ? {
        used: aiResult.fromOpenAI || false,
        risk: aiResult.risk,
        confidence: aiResult.confidence || null,
        category: aiResult.category || null
      } : null,
      decoded_data: decodedData,
      advanced_analysis: advancedResult ? {
        risk_score: advancedResult.riskScore,
        confidence: advancedResult.confidence
      } : null
    };
    
    await db.saveTransaction(txToSave, risk, message, ip);
  } catch (error) {
    console.error("Ошибка при сохранении в БД:", error.message);
  }

  // Собираем все предупреждения для детального отчёта
  const allWarnings = [
    ...(dataWarnings || []),
    ...(valueWarnings || []),
    ...(aiResult?.red_flags || []),
    ...(advancedResult?.warnings || [])
  ];
  
  // Отправляем ответ с цветовыми индикаторами
  const riskColors = {
    high: "#ff4444",   // Красный
    medium: "#ffaa00", // Желтый
    low: "#44ff44"     // Зеленый
  };
  
  res.json({
    risk: risk,
    riskColor: riskColors[risk] || "#888888",
    explanation: message,
    recommendations: recommendations,
    received: tx,
    timestamp: new Date().toISOString(),
    savedToDB: true,
    aiAnalysis: aiResult,
    decodedData: decodedData,
    advancedAnalysis: advancedResult,
    learningPrediction: learningResult,
    addressCheck: addressCheckResult,
    detailedAnalysis: {
      addressValid: tx.to ? isValidEthereumAddress(tx.to) : null,
      warningsCount: allWarnings.length,
      warnings: allWarnings.slice(0, 10),
      checksPerformed: [
        "empty_transaction",
        "unlimited_approve", 
        "limited_approve",
        "burn_address",
        "large_amount",
        "address_validation",
        "address_reputation_check",
        "gas_check",
        "scam_address_check",
        "data_analysis",
        "suspicious_values",
        "new_functions_check",
        "ai_analysis",
        "advanced_analysis",
        "learning_prediction"
      ]
    }
  });
});

// Новый endpoint: Получить историю транзакций
app.get("/history", async function(req, res) {
  try {
    const limit = req.query.limit || 20;
    const history = await db.getHistory(parseInt(limit));
    res.json(history);
  } catch (error) {
    res.status(500).json({ 
      error: "Ошибка получения истории",
      details: error.message 
    });
  }
});

// Новый endpoint: Получить статистику
app.get("/stats", async function(req, res) {
  try {
    const stats = await db.getStats();
    res.json(stats);
  } catch (error) {
    res.status(500).json({ 
      error: "Ошибка получения статистики",
      details: error.message 
    });
  }
});

// Новый endpoint: Последние транзакции (для дашборда)
app.get("/recent", async function(req, res) {
  try {
    const limit = req.query.limit || 5;
    const recent = await db.getRecentTransactions(parseInt(limit));
    res.json(recent);
  } catch (error) {
    res.status(500).json({ 
      error: "Ошибка получения последних транзакций",
      details: error.message 
    });
  }
});

// Информация о БД
app.get("/db-info", async function(req, res) {
  try {
    const recent = await db.getRecentTransactions(3);
    const stats = await db.getStats();
    const aiStats = aiAnalyzer.getCacheStats();
    
    res.json({
      database: "SQLite",
      file: "transactions.db",
      recentTransactions: recent.length,
      stats: stats,
      aiStats: aiStats,
      endpoints: [
        "/analyze - анализировать транзакцию (POST)",
        "/history - история транзакций",
        "/stats - статистика по рискам",
        "/recent - последние транзакции",
        "/db-info - эта информация"
      ]
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Информация о системе
app.get("/system-info", function(req, res) {
  res.json({
    name: "AI Crypto Guard",
    version: "1.0.0",
    description: "Система анализа безопасности крипто-транзакций",
    features: [
      "Проверка unlimited approve",
      "Проверка валидности адресов",
      "Проверка репутации адресов (Etherscan)",
      "Чёрный/белый список адресов",
      "Анализ данных транзакций",
      "Детектирование scam паттернов",
      "История всех проверок",
      "Статистика по рискам",
      "AI анализ (OpenAI)",
      "Продвинутый эвристический анализ",
      "Система обучения на основе истории"
    ],
    aiStatus: {
      enabled: aiAnalyzer.enabled,
      usingSimulation: aiAnalyzer.useSimulation,
      cacheSize: aiAnalyzer.cache.size
    },
    addressCheckerStatus: addressChecker.getStats(),
    status: "active",
    timestamp: new Date().toISOString()
  });
});

// Endpoint для записи решения пользователя (для обучения)
app.post("/record-decision", async function(req, res) {
  try {
    const { txHash, predictedRisk, userAction, actualOutcome } = req.body;
    
    await learningSystem.recordDecision(txHash, predictedRisk, userAction, actualOutcome);
    
    res.json({
      success: true,
      message: "Decision recorded for learning"
    });
  } catch (error) {
    res.status(500).json({
      error: "Failed to record decision",
      details: error.message
    });
  }
});

// Endpoint для получения паттернов обучения
app.get("/learning-patterns", async function(req, res) {
  try {
    const patterns = Array.from(learningSystem.patterns.entries());
    res.json({
      patterns: patterns,
      decisionsCount: learningSystem.userDecisions.length
    });
  } catch (error) {
    res.status(500).json({
      error: "Failed to get learning patterns",
      details: error.message
    });
  }
});

// Очистка кэша AI
app.post("/clear-ai-cache", async function(req, res) {
  try {
    await aiAnalyzer.clearCache();
    res.json({ success: true, message: "AI cache cleared" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ═══════════════════════════════════════════════════════════
// ENDPOINTS ДЛЯ ПРОВЕРКИ АДРЕСОВ
// ═══════════════════════════════════════════════════════════

// Проверка адреса (GET)
app.get("/check-address", async function(req, res) {
  try {
    const address = req.query.address;
    
    if (!address) {
      return res.status(400).json({ 
        error: "Address parameter is required",
        example: "/check-address?address=0x742d35Cc6634C0532925a3b844Bc9e"
      });
    }
    
    const result = await addressChecker.checkAddress(address);
    res.json(result);
    
  } catch (error) {
    res.status(500).json({ 
      error: "Failed to check address",
      details: error.message 
    });
  }
});

// Проверка адреса (POST)
app.post("/check-address", async function(req, res) {
  try {
    const { address } = req.body;
    
    if (!address) {
      return res.status(400).json({ 
        error: "Address is required in request body"
      });
    }
    
    const result = await addressChecker.checkAddress(address);
    res.json(result);
    
  } catch (error) {
    res.status(500).json({ 
      error: "Failed to check address",
      details: error.message 
    });
  }
});

// Получение статистики проверки адресов
app.get("/address-stats", function(req, res) {
  try {
    const stats = addressChecker.getStats();
    res.json(stats);
  } catch (error) {
    res.status(500).json({ 
      error: "Failed to get address stats",
      details: error.message 
    });
  }
});

// Добавление адреса в чёрный список
app.post("/blacklist/add", async function(req, res) {
  try {
    const { address, reason } = req.body;
    
    if (!address) {
      return res.status(400).json({ error: "Address is required" });
    }
    
    await addressChecker.addToBlacklist(address, reason);
    
    res.json({
      success: true,
      message: "Address added to blacklist",
      address: address.toLowerCase()
    });
  } catch (error) {
    res.status(500).json({ 
      error: "Failed to add to blacklist",
      details: error.message 
    });
  }
});

// Добавление адреса в белый список
app.post("/whitelist/add", async function(req, res) {
  try {
    const { address, reason } = req.body;
    
    if (!address) {
      return res.status(400).json({ error: "Address is required" });
    }
    
    await addressChecker.addToWhitelist(address, reason);
    
    res.json({
      success: true,
      message: "Address added to whitelist",
      address: address.toLowerCase()
    });
  } catch (error) {
    res.status(500).json({ 
      error: "Failed to add to whitelist",
      details: error.message 
    });
  }
});

// Очистка кэша адресов
app.post("/clear-address-cache", async function(req, res) {
  try {
    await addressChecker.clearCache();
    res.json({ success: true, message: "Address cache cleared" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(3000, function() {
  console.log("=".repeat(50));
  console.log("🚀 AI Crypto Guard запущен на http://localhost:3000");
  console.log("=".repeat(50));
  console.log("📊 Основные эндпоинты:");
  console.log("🔍 Анализ:         http://localhost:3000/analyze");
  console.log("📋 История:        http://localhost:3000/history");
  console.log("📈 Статистика:     http://localhost:3000/stats");
  console.log("🔄 Последние:      http://localhost:3000/recent");
  console.log("📍 Проверка адреса: http://localhost:3000/check-address?address=0x...");
  console.log("ℹ️  Инфо о БД:      http://localhost:3000/db-info");
  console.log("⚙️  Система:        http://localhost:3000/system-info");
  console.log("🌐 Веб-интерфейс:   http://localhost:3000");
  console.log("=".repeat(50));
  console.log("🤖 AI Статус:");
  console.log("   Включен:", aiAnalyzer.enabled);
  console.log("   Симуляция:", aiAnalyzer.useSimulation);
  console.log("   Кэш:", aiAnalyzer.cache.size, "записей");
  console.log("=".repeat(50));
  console.log("📍 Address Checker:");
  const addrStats = addressChecker.getStats();
  console.log("   Etherscan API:", addrStats.etherscanEnabled ? "✅ Подключен" : "⚠️ Не настроен");
  console.log("   Известных контрактов:", addrStats.knownContracts);
  console.log("   В чёрном списке:", addrStats.blacklistSize);
  console.log("   В белом списке:", addrStats.whitelistSize);
  console.log("   Кэш адресов:", addrStats.cacheSize);
  console.log("=".repeat(50));
});
