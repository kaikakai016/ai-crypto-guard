# 🚀 AI Crypto Guard

**AI Crypto Guard** - это система анализа безопасности крипто-транзакций с Chrome расширением, которая перехватывает транзакции из MetaMask и анализирует их через AI (OpenRouter) и эвристические алгоритмы.

![Version](https://img.shields.io/badge/version-1.1.0-blue.svg)
![License](https://img.shields.io/badge/license-MIT-green.svg)
![Node](https://img.shields.io/badge/node-%3E%3D18.0.0-brightgreen.svg)

## 🎯 Возможности

- ✅ **Перехват транзакций** - Автоматический перехват транзакций из MetaMask
- 🤖 **AI Анализ** - Анализ через OpenRouter (GPT-4, Claude, Llama) + fallback симуляция
- 📍 **Проверка адресов** - Репутация адресов через Etherscan API
- 🛡️ **База scam адресов** - Автоматическое обновление известных мошенников
- 🔍 **Эвристический анализ** - Продвинутые проверки на scam паттерны
- 🧠 **Система обучения** - Обучение на основе решений пользователя
- 🚨 **Предупреждения** - Мгновенные уведомления о высоком риске
- 📊 **История и статистика** - Полная история всех проверок
- 🌐 **Веб-интерфейс** - Удобный дашборд для анализа
- 📝 **Чёрный/Белый список** - Управление доверенными и опасными адресами

## 🛡️ Типы обнаруживаемых угроз

| Угроза | Описание | Уровень риска |
|--------|----------|---------------|
| Unlimited Approve | Неограниченный доступ к токенам | 🔴 Высокий |
| Token Burn | Отправка на нулевой адрес | 🔴 Высокий |
| Scam Addresses | Известные мошеннические адреса | 🔴 Высокий |
| Invalid Address | Неверный формат адреса | 🔴 Высокий |
| Large Transfer | Крупные суммы (>5 ETH) | 🟡 Средний |
| High Gas Price | Подозрительно высокий газ | 🟡 Средний |
| Phishing Keywords | Подозрительные ключевые слова | 🟡 Средний |
| Dust Attack | Очень маленькие суммы | 🟡 Средний |

## 📦 Установка

### 1. Клонирование репозитория

```bash
git clone https://github.com/your-username/ai-crypto-guard.git
cd ai-crypto-guard
```

### 2. Установка зависимостей

```bash
npm install
```

### 3. Настройка окружения

```bash
cp .env.example .env
# Отредактируйте .env и добавьте ваш OPENROUTER_API_KEY (опционально)
```

**Получение OpenRouter API ключа:**
1. Перейдите на https://openrouter.ai/keys
2. Создайте бесплатный аккаунт
3. Скопируйте API ключ
4. Добавьте в `.env` файл

### 4. Запуск сервера

```bash
npm start
# или
node index.js
```

Сервер запустится на `http://localhost:3000`

### 5. Установка Chrome расширения

1. Откройте Chrome и перейдите на `chrome://extensions/`
2. Включите "Режим разработчика" (Developer mode)
3. Нажмите "Загрузить распакованное" (Load unpacked)
4. Выберите папку `extension/`

## 🚀 Использование

### Веб-интерфейс

Откройте `http://localhost:3000` в браузере:

- **Scanner** - Анализ транзакций вручную
- **History** - История всех проверок
- **Stats** - Статистика и аналитика

### Chrome расширение

Расширение автоматически перехватывает транзакции из MetaMask:

1. Откройте любой dApp (например, Uniswap)
2. Начните транзакцию в MetaMask
3. AI Crypto Guard проанализирует её автоматически
4. При высоком риске появится предупреждение

### API Endpoints

| Endpoint | Метод | Описание |
|----------|-------|----------|
| `/analyze` | POST | Анализ транзакции |
| `/history` | GET | История транзакций |
| `/stats` | GET | Статистика по рискам |
| `/recent` | GET | Последние транзакции |
| `/system-info` | GET | Информация о системе |
| `/db-info` | GET | Информация о БД |
| `/check-address` | GET/POST | Проверка репутации адреса |
| `/address-stats` | GET | Статистика проверки адресов |
| `/blacklist/add` | POST | Добавить в чёрный список |
| `/whitelist/add` | POST | Добавить в белый список |

### Пример запроса к API

```bash
curl -X POST http://localhost:3000/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "to": "0x742d35Cc6634C0532925a3b844Bc9e",
    "value": "1.5",
    "data": "0x095ea7b3ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
  }'
```

## 🔧 Конфигурация

### Переменные окружения

| Переменная | Описание | По умолчанию |
|------------|----------|--------------|
| `OPENROUTER_API_KEY` | Ключ OpenRouter API | - |
| `AI_MODEL` | Модель AI (Claude, GPT-4, Llama) | anthropic/claude-3.5-sonnet |
| `ETHERSCAN_API_KEY` | Ключ Etherscan API | - |
| `PORT` | Порт сервера | 3000 |

### Обновление базы scam адресов

```bash
# Обновить базу известных мошенников
npm run update-scam-db
```

Это скачает адреса из:
- CryptoScamDB (если настроен API ключ)
- Chainabuse (если настроен API ключ)
- Локального файла `scam-data/custom-scams.txt`

### Получение API ключей

#### OpenRouter API Key (рекомендуется)

1. Перейдите на https://openrouter.ai/keys
2. Создайте бесплатный аккаунт
3. Скопируйте API ключ (начинается с `sk-or-v1-`)
4. Добавьте в `.env` файл:
   ```env
   OPENROUTER_API_KEY=sk-or-v1-your-key-here
   AI_MODEL=anthropic/claude-3.5-sonnet
   ```

> 💡 **Без API ключа система будет использовать симуляцию AI анализа**
> 
> 📖 Подробнее: [OPENROUTER_SETUP.md](OPENROUTER_SETUP.md)

#### Etherscan API Key (опционально)

1. Перейдите на https://etherscan.io/apis
2. Зарегистрируйтесь и создайте ключ
3. Добавьте в `.env` файл

## 🏗️ Архитектура

```
ai-crypto-guard/
├── index.js                 # Главный сервер Express
├── ai-analyzer.js          # AI анализатор (OpenRouter + симуляция)
├── address-checker.js      # Проверка репутации адресов
├── advanced-analyzer.js    # Продвинутый эвристический анализ
├── database.js             # SQLite база данных
├── learning-system.js      # Система обучения
├── update-scam-db.js       # Обновление базы scam адресов
├── package.json            # Зависимости
├── .env.example            # Пример конфигурации
├── blacklist.json          # Чёрный список адресов
├── whitelist.json          # Белый список адресов
│
├── public/                 # Веб-интерфейс
│   ├── index.html         # Главная страница
│   ├── history.html       # История транзакций
│   └── stats.html         # Статистика
│
└── extension/              # Chrome расширение
    ├── manifest.json      # Манифест расширения
    ├── background.js      # Фоновая служба
    ├── content.js        # Перехват MetaMask
    ├── popup.html        # Всплывающее окно
    └── popup.js          # Логика popup
```

## 🔍 Как это работает

### Процесс анализа транзакции

1. **Перехват** - Расширение перехватывает `eth_sendTransaction` из MetaMask
2. **Отправка** - Данные транзакции отправляются на бэкенд
3. **Проверки** - Выполняется 14+ различных проверок безопасности
4. **AI Анализ** - OpenAI GPT анализирует транзакцию (или симуляция)
5. **Продвинутый анализ** - Эвристические алгоритмы проверяют паттерны
6. **Обучение** - Система обучения проверяет похожие паттерны
7. **Результат** - Комбинированный результат с рекомендациями
8. **Сохранение** - Результат сохраняется в БД

### Уровни риска

- 🟢 **Low** - Транзакция безопасна
- 🟡 **Medium** - Требует внимания
- 🔴 **High** - Опасно, рекомендуется отмена

## 🧪 Тестирование

### Тестовые транзакции

В веб-интерфейсе доступны готовые примеры:

- **Unlimited Approve** - Неограниченный доступ к токенам
- **Limited Approve** - Ограниченное разрешение
- **Token Burn** - Сжигание токенов
- **Large Transfer** - Крупный перевод
- **Safe Transaction** - Безопасная транзакция

### Ручное тестирование

```bash
# Тест unlimited approve
curl -X POST http://localhost:3000/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "type": "approve",
    "amount": "unlimited",
    "to": "0x7a250d5630B4cF539739dF2C5dAcb4c659f2488d",
    "data": "0x095ea7b3ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
  }'
```

## 🛣️ Roadmap

### ✅ Реализовано

- [x] Базовый сервер с API
- [x] Проверка unlimited approve
- [x] Проверка валидности адресов
- [x] AI анализ (OpenAI + симуляция)
- [x] Chrome расширение
- [x] История и статистика
- [x] Система обучения
- [x] Продвинутый эвристический анализ

### 🚧 В разработке

- [ ] Интеграция Etherscan API
- [ ] Проверка репутации контрактов
- [ ] Whitelist/Blacklist пользователя
- [ ] Telegram бот для уведомлений
- [ ] Multi-chain поддержка (BNB, Polygon, Arbitrum)

### 📋 В планах

- [ ] Экспорт истории в CSV/PDF
- [ ] Мобильное приложение
- [ ] Интеграция с WalletConnect
- [ ] Децентрализованная репутация контрактов

## 🤝 Вклад в проект

1. Fork репозитория
2. Создайте feature branch (`git checkout -b feature/amazing-feature`)
3. Commit изменения (`git commit -m 'Add amazing feature'`)
4. Push в branch (`git push origin feature/amazing-feature`)
5. Откройте Pull Request

## 📄 Лицензия

Распространяется под лицензией MIT. См. [LICENSE](LICENSE) для подробностей.

## ⚠️ Отказ от ответственности

**AI Crypto Guard** предоставляется "как есть" без каких-либо гарантий. Это инструмент для помощи в анализе транзакций, но он не может гарантировать 100% защиту от всех видов мошенничества. Всегда:

- Дважды проверяйте адреса получателей
- Используйте лимитированный approve
- Проверяйте контракты на Etherscan
- Не доверяйте незнакомым контрактам

## 📞 Поддержка

Если у вас есть вопросы или предложения:

- Создайте Issue в репозитории
- Свяжитесь с нами через email
- Присоединяйтесь к нашему Telegram каналу

---

**Сделано с ❤️ для безопасности Web3**
