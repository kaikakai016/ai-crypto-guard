# 🤖 Настройка AI для AI Crypto Guard

## Обзор

AI Crypto Guard поддерживает несколько вариантов AI анализа:

1. **OpenAI GPT** (рекомендуется) - Полноценный AI анализ
2. **Симуляция AI** (бесплатно) - Локальный эвристический анализ
3. **Собственная модель** - Интеграция с другими AI провайдерами

## Вариант 1: OpenAI GPT (Рекомендуется)

### Получение API ключа

1. Перейдите на https://platform.openai.com/api-keys
2. Войдите или создайте аккаунт
3. Нажмите **"Create new secret key"**
4. Скопируйте ключ (начинается с `sk-`)

### Настройка

```bash
# Отредактируйте .env файл
nano .env
```

Добавьте:
```env
OPENAI_API_KEY=sk-your-actual-key-here
AI_ENABLED=true
AI_MODEL=gpt-3.5-turbo
```

### Перезапуск

```bash
# Остановите сервер (Ctrl+C) и запустите снова
npm start
```

### Проверка

```bash
curl http://localhost:3000/system-info
```

В ответе должно быть:
```json
{
  "aiStatus": {
    "enabled": true,
    "usingSimulation": false,
    "cacheSize": 0
  }
}
```

## Вариант 2: Симуляция AI (Бесплатно)

Если у вас нет OpenAI API ключа, система автоматически использует **симуляцию AI**.

### Что включает симуляция:

- ✅ Проверка unlimited approve
- ✅ Проверка нулевого адреса (burn)
- ✅ Анализ больших сумм
- ✅ Проверка газа
- ✅ Декодирование данных транзакции
- ✅ Обнаружение подозрительных паттернов
- ✅ Проверка валидности адресов

### Преимущества симуляции:

- 🆓 Полностью бесплатно
- ⚡ Мгновенный ответ (нет задержки API)
- 🔒 Нет отправки данных внешним сервисам
- 💪 Работает офлайн

### Недостатки:

- 🤖 Нет "умного" анализа контекста
- 📚 Ограниченная база знаний о scam
- 🎯 Меньше точность для сложных случаев

## Вариант 3: Альтернативные AI провайдеры

### Anthropic Claude

```javascript
// ai-analyzer.js - добавьте поддержку Claude
const Anthropic = require('@anthropic-ai/sdk');

class AIAnalyzer {
  constructor() {
    // ... существующий код ...
    
    // Добавляем Claude
    this.anthropic = new Anthropic({
      apiKey: process.env.ANTHROPIC_API_KEY
    });
  }
  
  async analyzeWithClaude(tx) {
    const response = await this.anthropic.messages.create({
      model: 'claude-3-opus-20240229',
      max_tokens: 500,
      messages: [{
        role: 'user',
        content: this.buildPrompt(tx)
      }]
    });
    
    return this.parseResponse(response.content[0].text);
  }
}
```

### Google Gemini

```javascript
const { GoogleGenerativeAI } = require('@google/generative-ai');

class AIAnalyzer {
  constructor() {
    // ... существующий код ...
    
    // Добавляем Gemini
    this.gemini = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
  }
  
  async analyzeWithGemini(tx) {
    const model = this.gemini.getGenerativeModel({ model: 'gemini-pro' });
    
    const result = await model.generateContent(this.buildPrompt(tx));
    const response = await result.response;
    
    return this.parseResponse(response.text());
  }
}
```

### Локальная модель (Ollama)

```javascript
// Использование локальной модели через Ollama
async analyzeWithOllama(tx) {
  const response = await fetch('http://localhost:11434/api/generate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'llama2',
      prompt: this.buildPrompt(tx),
      stream: false
    })
  });
  
  const result = await response.json();
  return this.parseResponse(result.response);
}
```

## 💰 Стоимость OpenAI API

### Цены (на февраль 2025):

| Модель | Вход | Выход |
|--------|------|-------|
| GPT-3.5-turbo | $0.50 / 1M tokens | $1.50 / 1M tokens |
| GPT-4 | $30.00 / 1M tokens | $60.00 / 1M tokens |
| GPT-4-turbo | $10.00 / 1M tokens | $30.00 / 1M tokens |

### Расчет стоимости

Один анализ транзакции:
- Вход: ~500 tokens
- Выход: ~200 tokens

**GPT-3.5-turbo:**
```
(500 * $0.50 + 200 * $1.50) / 1,000,000 = $0.00055 за анализ
```

**10,000 анализов = ~$5.50**

### Экономия с кэшем

AI Crypto Guard кэширует результаты анализа:
- Повторные похожие транзакции = бесплатно
- Типичная экономия: 30-50%

## 🔒 Безопасность API ключа

### Лучшие практики:

1. **Никогда не коммитьте ключ в git**
   ```bash
   # Добавьте в .gitignore
   echo ".env" >> .gitignore
   ```

2. **Используйте ограниченные ключи**
   - В OpenAI dashboard установите лимиты
   - Включите уведомления о расходах

3. **Регулярно ротируйте ключи**
   - Меняйте каждые 3 месяца
   - Отзывайте при подозрениях

4. **Мониторьте использование**
   ```bash
   # Проверьте статистику кэша
   curl http://localhost:3000/db-info
   ```

## 📊 Мониторинг AI анализа

### Статистика кэша

```bash
curl http://localhost:3000/db-info
```

Ответ:
```json
{
  "aiStats": {
    "size": 150,
    "enabled": true,
    "usingSimulation": false
  }
}
```

### Очистка кэша

```bash
curl -X POST http://localhost:3000/clear-ai-cache
```

## 🛠️ Отладка AI

### Включение подробных логов

```bash
# В .env добавьте
DEBUG=ai-analyzer
NODE_ENV=development
```

### Проверка запроса к OpenAI

```bash
# Тест с подробным выводом
curl -X POST http://localhost:3000/analyze \
  -H "Content-Type: application/json" \
  -d '{
    "to": "0x742d35Cc6634C0532925a3b844Bc9e",
    "value": "1.0",
    "data": "0x095ea7b3ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff"
  }' | jq
```

### Проверка в консоли

```javascript
// В консоли сервера
const AIAnalyzer = require('./ai-analyzer');
const ai = new AIAnalyzer();

ai.analyzeTransaction({
  to: '0x742d35Cc6634C0532925a3b844Bc9e',
  value: '1.0'
}).then(console.log);
```

## 🔄 Переключение между режимами

### Принудительное включение симуляции

```bash
# В .env
AI_ENABLED=false
```

Или в коде:
```javascript
const aiAnalyzer = new AIAnalyzer();
aiAnalyzer.useSimulation = true;
```

### Проверка текущего режима

```bash
curl http://localhost:3000/system-info | jq '.aiStatus'
```

## 🎯 Рекомендации

### Для разработки:
- Используйте **симуляцию** - быстрее и бесплатно
- Тестируйте с разными типами транзакций

### Для production:
- Получите **OpenAI API ключ** - лучшая точность
- Включите **кэширование** - экономия средств
- Настройте **мониторинг** - контроль расходов

### Для приватности:
- Используйте **симуляцию** или **локальную модель**
- Данные не покидают ваш сервер

---

**Выбор за вами! Симуляция работает отлично, но OpenAI дает более точный анализ.** 🚀
